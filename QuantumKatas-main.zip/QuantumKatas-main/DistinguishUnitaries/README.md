﻿# Welcome!

The "Distinguish Unitaries" kata offers tasks in which you are given a unitary and have to figure out which of the list it is by designing and performing experiments on it.
