# Welcome!

This folder contains a tutorial on the Grover's search algorithm - one of the most famous algorithms in quantum computing. It focuses on exploring the high-level behavior of the algorithm.
