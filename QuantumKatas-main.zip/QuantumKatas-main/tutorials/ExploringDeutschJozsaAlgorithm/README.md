# Welcome!

This folder contains a Notebook tutorial on the Deutsch-Jozsa algorithm - a quantum computing algorithm that has no practical use, but is famous for being one of the first examples of a quantum algorithm that is exponentially faster than any deterministic classical algorithm.
