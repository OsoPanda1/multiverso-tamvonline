# Welcome!

This folder contains a tutorial on linear algebra that explains some of the mathematical background required to work with quantum computing.
Linear algebra describes the properties of matrices and vectors, which are used to represent quantum states and operations on those states.
