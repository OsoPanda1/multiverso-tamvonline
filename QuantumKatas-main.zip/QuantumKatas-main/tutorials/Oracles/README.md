# Welcome!

This folder contains a tutorial on quantum oracles - a fundamental concept for many quantum algorithms.
