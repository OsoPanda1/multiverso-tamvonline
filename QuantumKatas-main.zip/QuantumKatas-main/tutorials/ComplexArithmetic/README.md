# Welcome!

This folder contains a tutorial on complex arithmetic that explains some of the mathematical background required to work with quantum computing.
Complex arithmetic deals with imaginary and complex numbers, which arise from an attempt to take the square root of negative numbers.
