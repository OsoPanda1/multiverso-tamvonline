# Welcome!

This folder contains a Notebook tutorial on quantum random number generation - 
an application of quantum computing that requires few qubits and offers true random numbers generated using the principles of quantum mechanics.
