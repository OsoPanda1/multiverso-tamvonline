# Welcome!

The "Unitary Patterns" kata offers tasks on creating unitary transformations which can be represented 
with matrices of certain shapes (with certain pattern of zero and non-zero values).
