# Sourcegraph with Docker Compose deployment reference

This directory contains the Sourcegraph with Docker Compose deployment reference.

To learn more about deploying, configuring, and upgrading a Sourcegraph with Docker Compose installation, please refer to our documentation: [Sourcegraph with Docker Compose](https://docs.sourcegraph.com/admin/install/docker-compose)
