//+build tools

package tools

import (
	// pins update-docker-tags CLI
	_ "github.com/sourcegraph/update-docker-tags"
)
