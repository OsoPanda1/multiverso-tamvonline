module.exports = require('@sourcegraph/prettierrc')
