Notice
======

OpenFermion-Cirq is deprecated and no longer maintained. Its functionality has been merged
into OpenFermion_. Please use OpenFermion instead.

.. _OpenFermion: https://github.com/quantumlib/OpenFermion

Copyright 2018 The OpenFermion Developers.
This is not an official Google product.
