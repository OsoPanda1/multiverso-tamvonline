.. OpenFermion-Cirq documentation master file, created by
   sphinx-quickstart on Mon Jul 16 00:40:07 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to OpenFermion-Cirq's documentation!
============================================

.. toctree::
   :maxdepth: 2

   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
