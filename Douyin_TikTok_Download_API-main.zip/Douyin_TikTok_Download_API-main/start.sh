#!/bin/sh

# Starting the Python application directly using python3
python3 start.py
