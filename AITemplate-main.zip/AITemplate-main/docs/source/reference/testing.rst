aitemplate.testing
==================

detect_target
-------------
.. automodule:: aitemplate.testing.detect_target
   :members:
   :imported-members:
   :exclude-members: CUDA, ROCM, Popen
   :autosummary:


benchmark_pt
------------
.. automodule:: aitemplate.testing.benchmark_pt
   :members:
   :imported-members:
   :exclude-members: CUDA, ROCM, Popen
   :autosummary:

benchmark_ait
-------------
.. automodule:: aitemplate.testing.benchmark_ait
   :members:
   :imported-members:
   :exclude-members: CUDA, ROCM, Popen
   :autosummary: