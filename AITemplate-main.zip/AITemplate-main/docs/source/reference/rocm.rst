aitemplate.backend.rocm
===========================

target_def
----------
.. automodule:: aitemplate.backend.rocm.target_def
   :members: 
   :imported-members: 
   :exclude-members:
   :autosummary:

