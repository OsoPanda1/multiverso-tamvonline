# AITemplate Documentation


## Build locally

1. Install AITemplate

2. Install Sphinx
```
pip install autodocsumm
pip install sphinx_rtd_theme
pip install sphinx_gallery
pip install sphinxcontrib-inlinesyntaxhighlight
pip install sphinx_toolbox
```

3. Build HTML
```
make html
```
