#!/bin/bash

apt install -y time
pip3 install numpy
pip3 install jinja2
