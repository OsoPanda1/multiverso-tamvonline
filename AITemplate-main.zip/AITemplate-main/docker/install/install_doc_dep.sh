#! /bin/bash
pip3 install autodocsumm
pip3 install sphinx_rtd_theme
pip3 install sphinx_gallery
pip3 install sphinxcontrib-inlinesyntaxhighlight
pip3 install sphinx_toolbox
