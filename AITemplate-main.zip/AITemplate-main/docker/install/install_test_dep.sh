#!/bin/bash

pip3 install click
pip3 install pytest
pip3 install parameterized
pip3 install pylint==2.13.9
pip3 install ufmt
pip3 install pyGithub
pip3 install gitpython
pip3 install xmltodict
pip3 install einops
