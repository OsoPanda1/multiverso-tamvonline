import React, { createContext, useContext, useReducer, Dispatch } from 'react';
import { ExperienceMode, ExperienceTheme, AudioPreset, XRScene, ThreatLevel } from '../types';

export interface ExperienceState {
  mode: ExperienceMode;
  theme: ExperienceTheme;
  audioPreset: AudioPreset;
  xrScene: XRScene;
  intensity: number; // 0.0 to 1.0 (Bloom, vibration, speed)
  volume: number;    // 0.0 to 1.0
  threatLevel: ThreatLevel; // Layer 7: Governance
}

type Action =
  | { type: 'SET_MODE'; mode: ExperienceMode }
  | { type: 'SET_THEME'; theme: ExperienceTheme }
  | { type: 'SET_AUDIO_PRESET'; preset: AudioPreset }
  | { type: 'SET_XR_SCENE'; scene: XRScene }
  | { type: 'SET_INTENSITY'; intensity: number }
  | { type: 'SET_VOLUME'; volume: number }
  | { type: 'SET_THREAT_LEVEL'; level: ThreatLevel };

const initialState: ExperienceState = {
  mode: 'default',
  theme: 'cyber_aqua',
  audioPreset: 'off',
  xrScene: 'lobby',
  intensity: 0.5,
  volume: 0.5,
  threatLevel: ThreatLevel.NOMINAL,
};

function experienceReducer(state: ExperienceState, action: Action): ExperienceState {
  switch (action.type) {
    case 'SET_MODE':
      // Auto-adjust dependent states for convenience, can be overridden by specific commands
      let autoIntensity = state.intensity;
      let autoTheme = state.theme;
      
      if (action.mode === 'ecstasy') {
          autoIntensity = 1.0;
          autoTheme = 'ritual';
      } else if (action.mode === 'calm') {
          autoIntensity = 0.2;
          autoTheme = 'nebula';
      } else if (action.mode === 'focus') {
          autoIntensity = 0.4;
          autoTheme = 'dark';
      }

      return { ...state, mode: action.mode, intensity: autoIntensity, theme: autoTheme };
      
    case 'SET_THEME':
      return { ...state, theme: action.theme };
      
    case 'SET_AUDIO_PRESET':
      return { ...state, audioPreset: action.preset };
      
    case 'SET_XR_SCENE':
      return { ...state, xrScene: action.scene };
      
    case 'SET_INTENSITY':
      return { ...state, intensity: action.intensity };

    case 'SET_VOLUME':
      return { ...state, volume: action.volume };
    
    case 'SET_THREAT_LEVEL':
      // GOVERNANCE PROTOCOL: Automate degradation of experience based on threat
      let forcedMode = state.mode;
      let forcedTheme = state.theme;
      
      if (action.level === ThreatLevel.CRITICAL) {
          forcedMode = 'collapse'; // Force collapse mode
          forcedTheme = 'dark';    // Force dark theme (dimming)
      } else if (action.level === ThreatLevel.ELEVATED) {
          forcedMode = 'focus';
      } else if (action.level === ThreatLevel.NOMINAL && state.threatLevel !== ThreatLevel.NOMINAL) {
          forcedMode = 'default'; // Restore
          forcedTheme = 'cyber_aqua';
      }

      return { 
        ...state, 
        threatLevel: action.level,
        mode: forcedMode,
        theme: forcedTheme
      };
      
    default:
      return state;
  }
}

const ExperienceContext = createContext<{
  state: ExperienceState;
  dispatch: Dispatch<Action>;
} | null>(null);

export const ExperienceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(experienceReducer, initialState);

  return (
    <ExperienceContext.Provider value={{ state, dispatch }}>
      {children}
    </ExperienceContext.Provider>
  );
}

export function useExperience() {
  const context = useContext(ExperienceContext);
  if (!context) {
    throw new Error('useExperience must be used within an ExperienceProvider');
  }
  return context;
}