export enum AppState {
  LOADING = 'LOADING',
  API_KEY_SELECT = 'API_KEY_SELECT',
  REGISTRATION = 'REGISTRATION',
  TUTORIAL = 'TUTORIAL',
  HUB = 'HUB', // This now contains both Social and Immersive sub-states
  DREAM_SPACE = 'DREAM_SPACE',
  MARKET = 'MARKET',
  GOVERNANCE = 'GOVERNANCE'
}

export type ViewMode = 'SOCIAL' | 'IMMERSIVE';

export enum InteractionType {
  NONE = 'NONE',
  ISABELLA_CHAT = 'ISABELLA_CHAT',
  TOTEM_VIEW = 'TOTEM_VIEW',
  PANEL_INFO = 'PANEL_INFO'
}

export type ExperienceMode = 'calm' | 'focus' | 'ecstasy' | 'collapse' | 'default';
export type ExperienceTheme = 'dark' | 'nebula' | 'ritual' | 'cyber_aqua' | 'golden_hour';
export type AudioPreset = 'off' | 'binaural' | 'concert' | 'deep_work';
export type XRScene = 'lobby' | 'dreamspace' | 'concert' | 'void';

// LAYER 7: GOVERNANCE & PROTECTION
export enum ThreatLevel {
  NOMINAL = 'NOMINAL',
  ELEVATED = 'ELEVATED',
  CRITICAL = 'CRITICAL'
}

// MULTIVERSE DIMENSIONS
export type DimensionType = 'NEXUS' | 'FINANCIAL' | 'KNOWLEDGE' | 'SPIRITUAL' | 'CREATIVE';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface ZoneData {
  id: string;
  name: string;
  dimension: DimensionType; // Multiverse classification
  category: 'SOCIAL' | 'ECONOMY' | 'KNOWLEDGE' | 'CREATIVE' | 'SYSTEM';
  description: string;
  position: [number, number, number];
  color: string;
  scale?: number;
}

export interface MarketItem {
  id: string;
  name: string;
  type: 'ASSET' | 'SERVICE' | 'REAL_ESTATE'; // Added Real Estate (DreamSpaces)
  price: number;
  currency: 'MSR' | 'TAMV';
  rarity: 'COMMON' | 'RARE' | 'LEGENDARY' | 'MYTHIC';
  description: string;
}

// DEKATEOTL GOVERNANCE
export interface Proposal {
  id: string;
  title: string;
  description: string;
  type: 'LEGISLATION' | 'DISPUTE' | 'UPGRADE';
  votesFor: number; // Weighted by MSR
  votesAgainst: number;
  status: 'ACTIVE' | 'PASSED' | 'REJECTED';
  endTime: number;
}

export interface UserProfile {
  id: string;
  username: string;
  avatarId?: string;
  citizenshipLevel: 'RESIDENT' | 'CITIZEN' | 'GUARDIAN' | 'ARCHITECT';
  reputation: number; // Total MSR
  // Granular MSR Attributes (The Soulbound stats)
  attributes: {
    wisdom: number;   // Educational/Documentation contributions
    community: number; // Voting/Justice/Dispute resolution
    creation: number; // Assets/DreamSpaces built
  };
  wallet: {
    msr: number; // Liquid MSR (Voting Power)
    tamv: number; // Utility Token
  }
}

export interface MediaItem {
  id: string;
  type: 'IMAGE' | 'VIDEO';
  url: string;
  title: string;
}