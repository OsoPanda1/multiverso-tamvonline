import React from 'react';
import { UserProfile } from '../../types';
import { X, Shield, Coins, CreditCard, Activity, Hexagon, BookOpen, Gavel, Hammer } from 'lucide-react';

interface WalletOverlayProps {
  profile: UserProfile;
  onClose: () => void;
}

const WalletOverlay: React.FC<WalletOverlayProps> = ({ profile, onClose }) => {
  
  // Calculate percentages for bars
  const maxStat = 1000;
  const wisdomPct = Math.min((profile.attributes.wisdom / maxStat) * 100, 100);
  const communityPct = Math.min((profile.attributes.community / maxStat) * 100, 100);
  const creationPct = Math.min((profile.attributes.creation / maxStat) * 100, 100);

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-40 p-4">
      <div className="w-full max-w-4xl bg-black/80 backdrop-blur-xl border border-cyan-900/50 rounded-3xl overflow-hidden shadow-[0_0_100px_rgba(34,211,238,0.1)] relative flex flex-col md:flex-row">
        
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        {/* LEFT COLUMN: IDENTITY CARD */}
        <div className="w-full md:w-1/3 bg-zinc-950/80 border-r border-zinc-800 p-8 flex flex-col items-center relative">
            <button onClick={onClose} className="absolute top-4 left-4 md:hidden text-zinc-500 hover:text-white">
                <X className="w-6 h-6" />
            </button>

            {/* Holographic Avatar Frame */}
            <div className="relative mb-6 group">
                <div className="absolute inset-0 rounded-full border-2 border-cyan-500/30 animate-[spin_10s_linear_infinite]"></div>
                <div className="absolute inset-[-4px] rounded-full border border-dashed border-cyan-500/20 animate-[spin_15s_linear_infinite_reverse]"></div>
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-black shadow-[0_0_30px_rgba(34,211,238,0.3)] bg-gradient-to-b from-cyan-900 to-black">
                     <div className="w-full h-full flex items-center justify-center text-4xl font-bold font-orbitron text-cyan-500">
                        {profile.username.substring(0,2).toUpperCase()}
                     </div>
                </div>
                <div className="absolute bottom-0 right-0 bg-cyan-500 text-black text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-widest border-2 border-black">
                    Lvl {Math.floor(profile.reputation / 100)}
                </div>
            </div>

            <h2 className="text-2xl font-bold text-white font-orbitron tracking-widest mb-1">{profile.username}</h2>
            <div className={`px-3 py-1 rounded border text-[10px] font-bold uppercase tracking-[0.2em] mb-8 ${
                profile.citizenshipLevel === 'ARCHITECT' ? 'bg-amber-500/20 text-amber-400 border-amber-500/50' :
                profile.citizenshipLevel === 'GUARDIAN' ? 'bg-purple-500/20 text-purple-400 border-purple-500/50' :
                'bg-cyan-500/20 text-cyan-400 border-cyan-500/50'
            }`}>
                {profile.citizenshipLevel}
            </div>

            {/* QR / ID Code */}
            <div className="w-full p-4 bg-white/5 rounded-xl border border-white/10 flex flex-col items-center">
                <div className="flex gap-1 mb-2">
                    {[1,2,3,4,5,6].map(i => <div key={i} className="w-1 h-4 bg-zinc-700"></div>)}
                </div>
                <p className="text-[10px] font-mono text-zinc-500">{profile.id.toUpperCase()}</p>
            </div>
        </div>

        {/* RIGHT COLUMN: METRICS & WALLET */}
        <div className="flex-1 p-8 flex flex-col relative">
            <button onClick={onClose} className="absolute top-6 right-6 hidden md:block text-zinc-500 hover:text-white transition-colors">
                <X className="w-6 h-6" />
            </button>

            <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                <Shield className="w-4 h-4" /> MSR Soulbound Attributes
            </h3>

            {/* The 3 Pillars of Reputation */}
            <div className="grid grid-cols-1 gap-6 mb-8">
                
                {/* Wisdom */}
                <div className="group">
                    <div className="flex justify-between items-end mb-2">
                        <div className="flex items-center gap-2 text-blue-400">
                            <BookOpen className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">Wisdom (Sabiduría)</span>
                        </div>
                        <span className="font-mono text-blue-300">{profile.attributes.wisdom}</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" style={{width: `${wisdomPct}%`}}></div>
                    </div>
                </div>

                {/* Community */}
                <div className="group">
                    <div className="flex justify-between items-end mb-2">
                        <div className="flex items-center gap-2 text-purple-400">
                            <Gavel className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">Community (Justicia)</span>
                        </div>
                        <span className="font-mono text-purple-300">{profile.attributes.community}</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]" style={{width: `${communityPct}%`}}></div>
                    </div>
                </div>

                {/* Creation */}
                <div className="group">
                    <div className="flex justify-between items-end mb-2">
                        <div className="flex items-center gap-2 text-amber-400">
                            <Hammer className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-wider">Creation (Obras)</span>
                        </div>
                        <span className="font-mono text-amber-300">{profile.attributes.creation}</span>
                    </div>
                    <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]" style={{width: `${creationPct}%`}}></div>
                    </div>
                </div>

            </div>

            <div className="w-full h-px bg-gradient-to-r from-transparent via-zinc-700 to-transparent my-4"></div>

            {/* Wallet Balances */}
            <div className="grid grid-cols-2 gap-4 mt-auto">
                 <div className="bg-gradient-to-br from-amber-950/30 to-black border border-amber-500/20 p-4 rounded-2xl flex flex-col justify-between group hover:border-amber-500/40 transition-colors">
                     <div className="flex items-center gap-2 text-amber-500 mb-2">
                         <Hexagon className="w-4 h-4" />
                         <span className="text-[10px] uppercase font-bold tracking-wider">MSR Liquid</span>
                     </div>
                     <span className="text-2xl font-mono text-white font-bold">{profile.wallet.msr}</span>
                 </div>

                 <div className="bg-gradient-to-br from-cyan-950/30 to-black border border-cyan-500/20 p-4 rounded-2xl flex flex-col justify-between group hover:border-cyan-500/40 transition-colors">
                     <div className="flex items-center gap-2 text-cyan-500 mb-2">
                         <CreditCard className="w-4 h-4" />
                         <span className="text-[10px] uppercase font-bold tracking-wider">TAMV Utility</span>
                     </div>
                     <span className="text-2xl font-mono text-white font-bold">{profile.wallet.tamv}</span>
                 </div>
            </div>

        </div>

      </div>
    </div>
  );
};

export default WalletOverlay;