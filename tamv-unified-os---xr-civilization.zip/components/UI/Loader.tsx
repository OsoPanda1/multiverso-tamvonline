import React, { useEffect, useState } from 'react';
import { ShieldCheck, Globe, Zap, ArrowRight, Fingerprint, Sparkles, Building2, Cpu } from 'lucide-react';
import StarfieldBackground from './StarfieldBackground';

interface LoaderProps {
  onComplete: () => void;
}

// REPLACE THESE URLs WITH THE ACTUAL IMAGE LINKS YOU HAVE
const UTAMV_LOGO_URL = "https://images.unsplash.com/photo-1635326444826-06c8f8d22144?q=80&w=400&auto=format&fit=crop"; // Bronze/Gold Seal Placeholder
const TAMV_TEXT_URL = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=600&auto=format&fit=crop"; // Cyber Text Placeholder
const ISABELLA_LOGO_URL = "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=400&auto=format&fit=crop"; // Heart/AI Placeholder

const BOOT_SEQUENCE = [
  "Verificando Credenciales UTAMV...",
  "Estableciendo enlace seguro TAMV Online...",
  "Conectando con Isabella AI...",
  "Cargando módulos de Realidad Extendida (XR)...",
  "Sincronizando Identidad Digital...",
  "Preparando entorno inmersivo...",
  "Sistemas listos."
];

const Loader: React.FC<LoaderProps> = ({ onComplete }) => {
  const [bootIndex, setBootIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [ready, setReady] = useState(false);
  const [activeLogo, setActiveLogo] = useState<0 | 1 | 2>(0); // 0: UTAMV, 1: TAMV, 2: ISABELLA

  useEffect(() => {
    // Text Sequence
    if (bootIndex < BOOT_SEQUENCE.length - 1) {
      const timeout = setTimeout(() => {
        setBootIndex(prev => prev + 1);
      }, 800);
      return () => clearTimeout(timeout);
    } else {
      setTimeout(() => setReady(true), 500);
    }
  }, [bootIndex]);

  useEffect(() => {
    // Progress & Logo Cycling
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        
        // Cycle logos based on progress
        if (prev < 35) setActiveLogo(0); // UTAMV
        else if (prev < 75) setActiveLogo(1); // TAMV
        else setActiveLogo(2); // Isabella

        return prev + 0.8; 
      });
    }, 40);

    return () => clearInterval(progressInterval);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden font-rajdhani text-white bg-black">
      <StarfieldBackground />
      
      {/* Overlay Vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#000000_90%)] z-10 pointer-events-none"></div>

      {/* Main Container */}
      <div className="relative z-20 flex flex-col items-center justify-center w-full max-w-4xl p-8 min-h-[600px]">
        
        {/* LOGO DISPLAY AREA */}
        <div className="relative w-full h-80 flex items-center justify-center mb-8">
            
            {/* 1. UTAMV LOGO (Education/Foundation) */}
            <div className={`absolute transition-all duration-1000 transform flex flex-col items-center ${activeLogo === 0 && !ready ? 'opacity-100 scale-100 blur-0' : 'opacity-0 scale-90 blur-xl translate-y-4'}`}>
                <div className="w-48 h-48 rounded-full border-4 border-amber-600/50 shadow-[0_0_60px_rgba(217,119,6,0.3)] flex items-center justify-center bg-black/50 backdrop-blur-md overflow-hidden p-2">
                    {/* Replace src with your UTAMV Seal image */}
                    <img src={UTAMV_LOGO_URL} alt="UTAMV" className="w-full h-full object-contain opacity-90" />
                </div>
                <h2 className="mt-6 text-2xl font-orbitron text-amber-500 tracking-[0.2em] font-bold text-center">UNIVERSIDAD DEL TAMV</h2>
                <p className="text-amber-200/50 text-sm tracking-widest uppercase mt-1">Excelencia Académica Virtual</p>
            </div>

            {/* 2. TAMV ONLINE LOGO (The Platform) */}
            <div className={`absolute transition-all duration-1000 transform flex flex-col items-center ${activeLogo === 1 && !ready ? 'opacity-100 scale-100 blur-0' : 'opacity-0 scale-90 blur-xl translate-y-4'}`}>
                 <div className="w-64 h-auto flex items-center justify-center">
                    {/* Replace src with your TAMV Text image */}
                    <img src={TAMV_TEXT_URL} alt="TAMV ONLINE" className="w-full h-full object-contain drop-shadow-[0_0_25px_rgba(34,211,238,0.6)]" />
                 </div>
                 <h2 className="mt-4 text-4xl font-black font-orbitron text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-white to-blue-500 tracking-widest">ONLINE</h2>
                 <p className="text-cyan-400/50 text-sm tracking-[0.5em] uppercase mt-2">Sistema Operativo Civilizatorio</p>
            </div>

            {/* 3. ISABELLA & FINAL STATE (The Guide) */}
            <div className={`absolute transition-all duration-1000 transform flex flex-col items-center ${activeLogo === 2 || ready ? 'opacity-100 scale-100 blur-0' : 'opacity-0 scale-90 blur-xl translate-y-4'}`}>
                <div className="relative">
                    {/* Pulse Rings */}
                    <div className="absolute inset-0 rounded-full border border-pink-500/30 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
                    <div className="absolute inset-[-20px] rounded-full border border-purple-500/20 animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite_1s]"></div>
                    
                    <div className="w-40 h-40 rounded-full flex items-center justify-center bg-gradient-to-br from-black to-purple-950/50 border border-purple-500/50 shadow-[0_0_50px_rgba(168,85,247,0.4)] overflow-hidden">
                        {/* Replace src with your Isabella Heart/Logo image */}
                        <img src={ISABELLA_LOGO_URL} alt="Isabella AI" className="w-full h-full object-contain p-4" />
                    </div>
                </div>
                <h2 className="mt-6 text-3xl font-orbitron text-white tracking-[0.1em] flex items-center gap-3">
                    ISABELLA <span className="text-purple-400 text-sm font-light border border-purple-500/50 px-2 py-0.5 rounded">AI 4.0</span>
                </h2>
                <p className="text-purple-200/60 text-xs tracking-widest uppercase mt-2">Inteligencia Nativa Extensible</p>
            </div>

        </div>

        {/* LOADING & STATUS */}
        <div className={`w-full max-w-lg transition-all duration-500 ${ready ? 'opacity-0 translate-y-10 pointer-events-none' : 'opacity-100'}`}>
            {/* Boot Log */}
            <div className="h-24 overflow-hidden flex flex-col justify-end mb-4 border-l-2 border-cyan-500/30 pl-4">
                 <p className="text-cyan-400 text-xs font-mono mb-1">{BOOT_SEQUENCE[bootIndex]}</p>
                 <div className="flex gap-1">
                    <span className="w-1 h-1 bg-cyan-500 animate-pulse"></span>
                    <span className="w-1 h-1 bg-cyan-500 animate-pulse delay-75"></span>
                    <span className="w-1 h-1 bg-cyan-500 animate-pulse delay-150"></span>
                 </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-1 bg-gray-900 rounded-full overflow-hidden relative">
                <div 
                    className="h-full bg-gradient-to-r from-amber-500 via-cyan-500 to-purple-600 transition-all duration-100 ease-out relative"
                    style={{ width: `${progress}%` }}
                >
                    <div className="absolute right-0 top-0 bottom-0 w-10 bg-white blur-md opacity-50"></div>
                </div>
            </div>
            <div className="flex justify-between text-[10px] uppercase text-gray-500 mt-2 font-mono">
                <span>Cargando Recursos...</span>
                <span>{Math.round(progress)}%</span>
            </div>
        </div>

        {/* ENTER BUTTON (Reveals when ready) */}
        {ready && (
            <div className="absolute bottom-20 animate-in fade-in slide-in-from-bottom-10 duration-1000 flex flex-col items-center">
                <button 
                    onClick={onComplete}
                    className="group relative w-64 h-16 bg-white/5 border border-white/20 hover:border-cyan-400/50 text-white font-orbitron text-lg tracking-[0.2em] uppercase transition-all duration-500 hover:bg-cyan-950/40 hover:scale-105 hover:shadow-[0_0_60px_rgba(34,211,238,0.2)] flex items-center justify-center overflow-hidden rounded-sm"
                >
                    <span className="relative z-10 group-hover:text-cyan-100 transition-colors">INICIAR SESIÓN</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/10 to-cyan-500/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                    
                    {/* Corner accents */}
                    <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-500 opacity-50 group-hover:opacity-100 transition-opacity"></div>
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-cyan-500 opacity-50 group-hover:opacity-100 transition-opacity"></div>
                </button>
                <p className="text-[10px] text-gray-500 mt-4 tracking-[0.2em] font-light animate-pulse">TOQUE PARA ACCEDER AL METAVERSO</p>
            </div>
        )}
        
        {/* Footer Status */}
        <div className="fixed bottom-6 w-full max-w-6xl flex justify-between text-[9px] uppercase tracking-widest text-gray-700 px-8 border-t border-white/5 pt-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3 h-3 text-amber-900" />
            <span>UTAMV: CERTIFIED</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe className="w-3 h-3 text-cyan-900" />
            <span>NET: GLOBAL-L0</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-3 h-3 text-purple-900" />
            <span>AI: ONLINE</span>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Loader;