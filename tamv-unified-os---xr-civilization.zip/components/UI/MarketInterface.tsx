import React, { useState, useMemo } from 'react';
import { X, Filter, ArrowUpDown, Search, Building2, Box, PenTool } from 'lucide-react';
import { MarketItem } from '../../types';

// Mock Data updated with DreamSpaces
const MARKET_ITEMS: MarketItem[] = [
  { id: '1', name: 'Neuro-Link Blueprint', type: 'ASSET', price: 500, currency: 'MSR', rarity: 'RARE', description: 'Schematics for neural interfacing.' },
  { id: '2', name: 'Avatar Rigging Service', type: 'SERVICE', price: 150, currency: 'TAMV', rarity: 'COMMON', description: 'Custom bone structure for VR avatars.' },
  { id: '3', name: 'Golden Totem Skin', type: 'ASSET', price: 5000, currency: 'MSR', rarity: 'LEGENDARY', description: 'Exclusive texture for governance totems.' },
  { id: '4', name: 'Smart Contract Audit', type: 'SERVICE', price: 1000, currency: 'MSR', rarity: 'RARE', description: 'Security verification for dApps.' },
  { id: '5', name: 'DreamSpace: Outer Rim Plot', type: 'REAL_ESTATE', price: 3000, currency: 'TAMV', rarity: 'COMMON', description: '16x16m sovereign parcel. Build your own physics.' },
  { id: '6', name: 'AI Voice Model', type: 'ASSET', price: 750, currency: 'TAMV', rarity: 'RARE', description: 'Custom voice synthesis model.' },
  { id: '7', name: 'DreamSpace: Core Node', type: 'REAL_ESTATE', price: 50000, currency: 'MSR', rarity: 'MYTHIC', description: 'A high-traffic node near the Nexus. High visibility.' },
  { id: '8', name: '3D Modeling Tutoring', type: 'SERVICE', price: 50, currency: 'TAMV', rarity: 'COMMON', description: '1 hour session with a master builder.' },
];

interface MarketInterfaceProps {
  onClose: () => void;
}

type SortOption = 'PRICE_ASC' | 'PRICE_DESC' | 'NAME_ASC';
type RarityFilter = 'ALL' | 'COMMON' | 'RARE' | 'LEGENDARY' | 'MYTHIC';

const MarketInterface: React.FC<MarketInterfaceProps> = ({ onClose }) => {
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'ASSET' | 'SERVICE' | 'REAL_ESTATE'>('ALL');
  const [rarityFilter, setRarityFilter] = useState<RarityFilter>('ALL');
  const [sort, setSort] = useState<SortOption>('NAME_ASC');
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = useMemo(() => {
    return MARKET_ITEMS
      .filter(item => {
        // Type Filter
        if (typeFilter !== 'ALL' && item.type !== typeFilter) return false;
        
        // Rarity Filter
        if (rarityFilter !== 'ALL' && item.rarity !== rarityFilter) return false;
        
        // Price Range
        const price = item.price;
        if (minPrice && price < parseFloat(minPrice)) return false;
        if (maxPrice && price > parseFloat(maxPrice)) return false;

        // Search
        if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;

        return true;
      })
      .sort((a, b) => {
        if (sort === 'PRICE_ASC') return a.price - b.price;
        if (sort === 'PRICE_DESC') return b.price - a.price;
        return a.name.localeCompare(b.name);
      });
  }, [typeFilter, rarityFilter, sort, minPrice, maxPrice, searchQuery]);

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-40 p-4 pointer-events-auto">
        {/* Container */}
        <div className="w-full max-w-6xl h-[90vh] bg-zinc-900 border border-zinc-800 rounded-3xl flex flex-col shadow-[0_0_80px_rgba(239,68,68,0.15)] overflow-hidden animate-in fade-in zoom-in duration-300">
            
            {/* Header */}
            <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-gradient-to-r from-red-950/30 to-zinc-900">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-900/20 rounded-xl flex items-center justify-center border border-red-500/20">
                         <span className="text-2xl">⚖️</span>
                    </div>
                    <div>
                        <h2 className="text-3xl text-white font-bold font-orbitron tracking-widest">MERCADO TRUEQUE</h2>
                        <p className="text-red-400/60 text-xs font-mono uppercase tracking-wider">Decentralized Asset Exchange // MSR Chain</p>
                    </div>
                </div>
                <button onClick={onClose} className="p-3 hover:bg-zinc-800 rounded-full text-zinc-400 hover:text-white transition-colors">
                    <X className="w-6 h-6" />
                </button>
            </div>

            <div className="flex flex-col lg:flex-row flex-1 overflow-hidden">
                
                {/* Sidebar Filters */}
                <div className="w-full lg:w-72 bg-zinc-900/50 border-r border-zinc-800 p-6 flex flex-col gap-8 overflow-y-auto">
                    
                    {/* Search */}
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                        <input 
                            type="text" 
                            placeholder="Search assets..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500/50 transition-colors"
                        />
                    </div>

                    {/* Filter Group: Type */}
                    <div>
                        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                            <Filter className="w-3 h-3" /> Asset Type
                        </h3>
                        <div className="flex flex-col gap-2">
                            {['ALL', 'ASSET', 'SERVICE', 'REAL_ESTATE'].map((type) => (
                                <button
                                    key={type}
                                    onClick={() => setTypeFilter(type as any)}
                                    className={`text-left px-3 py-2 rounded-md text-sm font-medium transition-all ${
                                        typeFilter === type 
                                        ? 'bg-red-900/20 text-red-400 border border-red-900/50' 
                                        : 'text-zinc-400 hover:bg-zinc-800 hover:text-white'
                                    }`}
                                >
                                    {type === 'ALL' ? 'All Types' : type.replace('_', ' ')}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Filter Group: Rarity */}
                    <div>
                        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Rarity</h3>
                        <div className="flex flex-wrap gap-2">
                            {['ALL', 'COMMON', 'RARE', 'LEGENDARY', 'MYTHIC'].map((r) => (
                                <button
                                    key={r}
                                    onClick={() => setRarityFilter(r as any)}
                                    className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-wider border transition-all ${
                                        rarityFilter === r
                                        ? 'bg-white text-black border-white'
                                        : 'bg-transparent text-zinc-500 border-zinc-800 hover:border-zinc-600'
                                    }`}
                                >
                                    {r}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Filter Group: Price */}
                    <div>
                        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Price Range</h3>
                        <div className="flex items-center gap-2">
                            <input 
                                type="number" 
                                placeholder="Min" 
                                value={minPrice}
                                onChange={(e) => setMinPrice(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500/50"
                            />
                            <span className="text-zinc-600">-</span>
                            <input 
                                type="number" 
                                placeholder="Max" 
                                value={maxPrice}
                                onChange={(e) => setMaxPrice(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-800 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500/50"
                            />
                        </div>
                    </div>
                </div>

                {/* Main Content */}
                <div className="flex-1 flex flex-col bg-zinc-900/30">
                    
                    {/* Toolbar */}
                    <div className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-900/50">
                        <span className="text-zinc-400 text-sm">
                            Showing <span className="text-white font-bold">{filteredItems.length}</span> results
                        </span>
                        
                        <div className="flex items-center gap-3">
                            <span className="text-zinc-500 text-xs font-bold uppercase">Sort By</span>
                            <div className="relative group">
                                <select 
                                    value={sort}
                                    onChange={(e) => setSort(e.target.value as SortOption)}
                                    className="appearance-none bg-zinc-950 border border-zinc-700 text-white text-xs font-bold uppercase rounded-lg pl-4 pr-8 py-2 focus:outline-none cursor-pointer hover:border-zinc-500"
                                >
                                    <option value="NAME_ASC">Name (A-Z)</option>
                                    <option value="PRICE_ASC">Price (Low to High)</option>
                                    <option value="PRICE_DESC">Price (High to Low)</option>
                                </select>
                                <ArrowUpDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-500 pointer-events-none" />
                            </div>
                        </div>
                    </div>

                    {/* Grid */}
                    <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                            {filteredItems.map(item => (
                                <div key={item.id} className="group flex flex-col bg-zinc-950 border border-zinc-800 hover:border-red-500/30 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-red-900/10 hover:-translate-y-1">
                                    
                                    {/* Image Placeholder */}
                                    <div className="h-40 bg-zinc-900 relative flex items-center justify-center overflow-hidden">
                                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.05),transparent)]"></div>
                                        <div className="w-20 h-20 bg-zinc-800 rounded-2xl rotate-45 flex items-center justify-center border border-zinc-700 group-hover:border-red-500/50 group-hover:scale-110 transition-all duration-500 shadow-xl">
                                            <span className="text-3xl -rotate-45 filter drop-shadow">
                                                {item.type === 'ASSET' ? <Box /> : 
                                                 item.type === 'SERVICE' ? <PenTool /> : 
                                                 <Building2 />}
                                            </span>
                                        </div>
                                        
                                        {/* Rarity Tag */}
                                        <div className="absolute top-3 right-3">
                                            <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wider backdrop-blur-md shadow-lg ${
                                                item.rarity === 'MYTHIC' ? 'bg-amber-500/20 text-amber-200 border border-amber-500/40 animate-pulse' :
                                                item.rarity === 'LEGENDARY' ? 'bg-yellow-500/20 text-yellow-200 border border-yellow-500/40' :
                                                item.rarity === 'RARE' ? 'bg-purple-500/20 text-purple-200 border border-purple-500/40' :
                                                'bg-zinc-700/50 text-zinc-300 border border-zinc-600'
                                            }`}>
                                                {item.rarity}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Content */}
                                    <div className="p-5 flex flex-col flex-1">
                                        <div className="flex justify-between items-start mb-2">
                                            <h3 className="text-base font-bold text-white font-orbitron group-hover:text-red-400 transition-colors">{item.name}</h3>
                                        </div>
                                        
                                        <p className="text-zinc-500 text-xs leading-relaxed mb-6 line-clamp-2 flex-1">{item.description}</p>

                                        <div className="flex items-center justify-between pt-4 border-t border-zinc-900">
                                            <div>
                                                <p className="text-[10px] text-zinc-500 uppercase font-bold">Price</p>
                                                <p className="text-lg font-mono font-bold text-white">
                                                    {item.price} <span className="text-sm text-red-500">{item.currency}</span>
                                                </p>
                                            </div>
                                            <button className="bg-white text-black px-4 py-2 rounded-lg text-xs font-bold uppercase hover:bg-red-600 hover:text-white transition-all transform hover:scale-105 active:scale-95 shadow-lg">
                                                Trade
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {filteredItems.length === 0 && (
                                <div className="col-span-full flex flex-col items-center justify-center py-20 text-zinc-600">
                                    <Search className="w-12 h-12 mb-4 opacity-20" />
                                    <p className="text-lg font-medium">No items found</p>
                                    <p className="text-sm">Try adjusting your filters</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default MarketInterface;