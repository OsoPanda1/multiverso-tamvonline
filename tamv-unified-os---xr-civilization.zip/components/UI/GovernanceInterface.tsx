import React, { useState } from 'react';
import { Proposal } from '../../types';
import { X, Scale, ThumbsUp, ThumbsDown, FileText, AlertTriangle, ScrollText } from 'lucide-react';

// Mock Proposals based on Repo Concepts
const MOCK_PROPOSALS: Proposal[] = [
  {
    id: 'prop-101',
    title: 'Protocol Upgrade: DreamSpace v2',
    description: 'Allocate 50,000 TAMV from treasury to upgrade the XR rendering engine for DreamSpaces, allowing higher poly-count assets.',
    type: 'UPGRADE',
    votesFor: 125000,
    votesAgainst: 15000,
    status: 'ACTIVE',
    endTime: Date.now() + 86400000 * 2
  },
  {
    id: 'prop-102',
    title: 'Dispute #44: Land Claim',
    description: 'User @NeonGhost claims ownership of Sector 7G based on legacy artifact possession. Council must decide validity.',
    type: 'DISPUTE',
    votesFor: 40000,
    votesAgainst: 42000,
    status: 'ACTIVE',
    endTime: Date.now() + 86400000
  },
  {
    id: 'prop-103',
    title: 'Legislation: Anti-Spam Tax',
    description: 'Implement a 0.5 TAMV cost for global broadcast messages to reduce noise in the Nexus hub.',
    type: 'LEGISLATION',
    votesFor: 800000,
    votesAgainst: 5000,
    status: 'PASSED',
    endTime: Date.now() - 100000
  }
];

interface GovernanceInterfaceProps {
  onClose: () => void;
  userMsr: number;
}

const GovernanceInterface: React.FC<GovernanceInterfaceProps> = ({ onClose, userMsr }) => {
  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'HISTORY' | 'MANIFESTO'>('ACTIVE');

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-md z-40 p-4 pointer-events-auto">
      <div className="w-full max-w-5xl h-[85vh] bg-zinc-950 border border-purple-900/50 rounded-3xl flex flex-col shadow-[0_0_100px_rgba(168,85,247,0.15)] overflow-hidden relative">
        
        {/* Background Graphic */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[100px] pointer-events-none"></div>

        {/* Header */}
        <div className="p-8 border-b border-zinc-800 flex justify-between items-center bg-gradient-to-r from-purple-950/40 to-zinc-950 z-10">
            <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-purple-900/20 rounded-2xl flex items-center justify-center border border-purple-500/30 shadow-[0_0_30px_rgba(168,85,247,0.2)]">
                     <Scale className="w-8 h-8 text-purple-400" />
                </div>
                <div>
                    <h2 className="text-4xl text-white font-bold font-orbitron tracking-widest">DEKATEOTL</h2>
                    <p className="text-purple-400/60 text-sm font-mono uppercase tracking-[0.2em] mt-1">Tribunal Descentralizado // Governance Layer 7</p>
                </div>
            </div>
            
            <div className="flex items-center gap-6">
                 <div className="text-right hidden md:block">
                    <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Your Voting Power</p>
                    <p className="text-2xl font-mono text-amber-500 font-bold">{userMsr.toLocaleString()} MSR</p>
                 </div>
                 <button onClick={onClose} className="p-3 hover:bg-zinc-800 rounded-full text-zinc-400 hover:text-white transition-colors">
                    <X className="w-6 h-6" />
                </button>
            </div>
        </div>

        {/* Navigation */}
        <div className="flex border-b border-zinc-800 px-8">
            {['ACTIVE', 'HISTORY', 'MANIFESTO'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`px-6 py-4 text-sm font-bold uppercase tracking-widest transition-all border-b-2 ${
                        activeTab === tab 
                        ? 'text-purple-400 border-purple-500 bg-purple-900/10' 
                        : 'text-zinc-500 border-transparent hover:text-zinc-300'
                    }`}
                >
                    {tab}
                </button>
            ))}
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-4 z-10 relative custom-scrollbar">
            
            {activeTab === 'MANIFESTO' ? (
                <div className="prose prose-invert max-w-none">
                     <div className="bg-zinc-900/50 border border-purple-500/20 p-8 rounded-2xl">
                         <div className="flex items-center gap-3 mb-6">
                             <ScrollText className="w-8 h-8 text-purple-500" />
                             <h3 className="text-2xl font-bold font-orbitron text-purple-100">THE MANIFESTO OF DIGITAL SOVEREIGNTY</h3>
                         </div>
                         
                         <div className="space-y-6 text-zinc-300 font-rajdhani text-lg">
                             <p><strong className="text-purple-400">Article I: Identity.</strong> Identity is Soulbound (MSR). It cannot be bought, sold, or transferred. It is the sum of one's actions: Wisdom, Community, and Creation.</p>
                             <p><strong className="text-purple-400">Article II: Economy.</strong> TAMV is the medium of exchange, but MSR is the measure of trust. Economic power shall not override meritocratic power.</p>
                             <p><strong className="text-purple-400">Article III: Space.</strong> DreamSpaces are sovereign territories. The creator of a space dictates its local laws, provided they do not violate the Layer 0 integrity.</p>
                             <p><strong className="text-purple-400">Article IV: Governance.</strong> The Dekateotl Tribunal is the final arbiter. Changes to the Protocol (Layer 0) require a supermajority of MSR.</p>
                         </div>
                         
                         <div className="mt-8 pt-8 border-t border-purple-500/20 flex justify-end">
                             <p className="text-xs font-mono text-zinc-500 uppercase tracking-widest">Signed by The First Architect // Block 0</p>
                         </div>
                     </div>
                </div>
            ) : (
                <>
                {MOCK_PROPOSALS.filter(p => activeTab === 'ACTIVE' ? p.status === 'ACTIVE' : p.status !== 'ACTIVE').map((proposal) => (
                    <div key={proposal.id} className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 hover:border-purple-500/30 transition-all group">
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex gap-4">
                                <div className={`mt-1 p-2 rounded-lg border ${
                                    proposal.type === 'UPGRADE' ? 'bg-cyan-900/20 border-cyan-500/30 text-cyan-400' :
                                    proposal.type === 'DISPUTE' ? 'bg-red-900/20 border-red-500/30 text-red-400' :
                                    'bg-amber-900/20 border-amber-500/30 text-amber-400'
                                }`}>
                                    {proposal.type === 'UPGRADE' && <FileText className="w-5 h-5" />}
                                    {proposal.type === 'DISPUTE' && <AlertTriangle className="w-5 h-5" />}
                                    {proposal.type === 'LEGISLATION' && <Scale className="w-5 h-5" />}
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-white font-orbitron mb-1">{proposal.title}</h3>
                                    <div className="flex gap-2 text-[10px] font-mono uppercase text-zinc-500">
                                        <span>ID: {proposal.id}</span>
                                        <span>•</span>
                                        <span>Ends in: {Math.ceil((proposal.endTime - Date.now()) / 3600000)} Hours</span>
                                    </div>
                                </div>
                            </div>
                            <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase border ${
                                proposal.status === 'ACTIVE' ? 'bg-green-900/20 border-green-500/30 text-green-400 animate-pulse' : 'bg-zinc-800 border-zinc-700 text-zinc-500'
                            }`}>
                                {proposal.status}
                            </div>
                        </div>

                        <p className="text-zinc-400 text-sm leading-relaxed mb-6 ml-[60px] max-w-3xl">
                            {proposal.description}
                        </p>

                        {/* Progress Bar */}
                        <div className="ml-[60px] mb-6">
                            <div className="flex justify-between text-[10px] uppercase font-bold text-zinc-500 mb-2">
                                <span>Yes ({((proposal.votesFor / (proposal.votesFor + proposal.votesAgainst)) * 100).toFixed(1)}%)</span>
                                <span>No ({((proposal.votesAgainst / (proposal.votesFor + proposal.votesAgainst)) * 100).toFixed(1)}%)</span>
                            </div>
                            <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden flex">
                                <div className="h-full bg-purple-500" style={{ width: `${(proposal.votesFor / (proposal.votesFor + proposal.votesAgainst)) * 100}%` }}></div>
                                <div className="h-full bg-zinc-600" style={{ width: `${(proposal.votesAgainst / (proposal.votesFor + proposal.votesAgainst)) * 100}%` }}></div>
                            </div>
                        </div>

                        {/* Actions */}
                        {proposal.status === 'ACTIVE' && (
                            <div className="ml-[60px] flex gap-4">
                                <button className="flex items-center gap-2 bg-purple-900/30 hover:bg-purple-600 border border-purple-500/30 hover:border-purple-400 text-purple-100 px-6 py-2 rounded-lg transition-all text-xs font-bold uppercase tracking-widest">
                                    <ThumbsUp className="w-4 h-4" /> Vote Yes
                                </button>
                                <button className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 px-6 py-2 rounded-lg transition-all text-xs font-bold uppercase tracking-widest">
                                    <ThumbsDown className="w-4 h-4" /> Vote No
                                </button>
                            </div>
                        )}
                    </div>
                ))}
                </>
            )}
        </div>
      </div>
    </div>
  );
};

export default GovernanceInterface;