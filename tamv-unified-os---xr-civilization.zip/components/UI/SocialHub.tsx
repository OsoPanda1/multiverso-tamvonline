import React from 'react';
import { 
  Home, Globe, ShoppingBag, Radio, User, 
  MessageSquare, Heart, Share2, MoreHorizontal, 
  Search, Bell, Zap, Play, Box, Layers
} from 'lucide-react';
import { UserProfile } from '../../types';

interface SocialHubProps {
  profile: UserProfile;
  onNavigate: (id: string) => void;
  onEnterImmersion: () => void;
}

const SocialHub: React.FC<SocialHubProps> = ({ profile, onNavigate, onEnterImmersion }) => {
  
  const FEED_POSTS = [
    {
      id: 1,
      author: 'Isabella Oracle',
      role: 'AI GUARDIAN',
      time: '2 min ago',
      content: 'El Tribunal Dekateotl ha abierto la sesión #404. Se discute la expansión del Distrito Financiero. Tu MSR es requerido.',
      likes: 1204,
      comments: 45,
      has3D: true,
      image: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?q=80&w=800&auto=format&fit=crop'
    },
    {
      id: 2,
      author: 'NeoArchitect_01',
      role: 'CITIZEN',
      time: '15 min ago',
      content: 'Acabo de desplegar mi nuevo DreamSpace "Zen Garden V2". Física de agua mejorada y audio binaural integrado. ¡Visiten!',
      likes: 89,
      comments: 12,
      has3D: true,
      image: 'https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=800&auto=format&fit=crop'
    },
    {
      id: 3,
      author: 'CryptoNomad',
      role: 'RESIDENT',
      time: '1 hour ago',
      content: 'Busco a alguien que me enseñe a modelar totems para ganar MSR (Wisdom). Pago en TAMV.',
      likes: 34,
      comments: 8,
      has3D: false,
    }
  ];

  return (
    <div className="absolute inset-0 z-30 flex flex-col pointer-events-none text-white font-rajdhani overflow-hidden perspective-1000">
      
      {/* TOP NAVIGATION BAR */}
      <div className="w-full h-16 bg-black/80 backdrop-blur-xl border-b border-white/10 flex items-center justify-between px-6 pointer-events-auto shadow-2xl z-50">
        <div className="flex items-center gap-4">
          <div className="text-2xl font-orbitron font-bold tracking-widest text-white flex items-center gap-2">
            <Globe className="w-6 h-6 text-cyan-400 animate-pulse" />
            TAMV <span className="text-cyan-500 text-sm border border-cyan-500/50 px-1 rounded">OS</span>
          </div>
          <div className="hidden md:flex items-center bg-zinc-900/80 border border-zinc-700 rounded-full px-4 py-2 w-96 ml-8 focus-within:border-cyan-500/50 transition-colors">
            <Search className="w-4 h-4 text-zinc-500 mr-2" />
            <input type="text" placeholder="Search citizens, assets, zones..." className="bg-transparent border-none outline-none text-sm w-full placeholder-zinc-600 text-white" />
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <button className="relative p-2 text-zinc-400 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <div className="flex items-center gap-3 pl-6 border-l border-zinc-800 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => onNavigate('profile')}>
             <div className="text-right hidden md:block">
               <div className="text-sm font-bold leading-none">{profile.username}</div>
               <div className="text-[10px] text-cyan-400 tracking-widest uppercase">{profile.citizenshipLevel}</div>
             </div>
             <div className="w-9 h-9 bg-gradient-to-tr from-cyan-900 to-blue-900 rounded-full border border-cyan-500/30 flex items-center justify-center font-orbitron font-bold">
               {profile.username.substring(0,2).toUpperCase()}
             </div>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT GRID */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT SIDEBAR (Navigation) */}
        <div className="w-20 md:w-64 bg-black/40 backdrop-blur-md border-r border-white/5 flex flex-col py-6 pointer-events-auto">
           <nav className="flex-1 space-y-2 px-3">
              {[
                { id: 'feed', icon: Home, label: 'Muro Global', active: true },
                { id: 'market', icon: ShoppingBag, label: 'Mercado Trueque' },
                { id: 'sanctuary', icon: Layers, label: 'Gobernanza' },
                { id: 'academy', icon: Box, label: 'Neo-Academia' },
                { id: 'dreamspace', icon: Zap, label: 'DreamSpaces' },
                { id: 'media', icon: Play, label: 'TAMV TV' },
              ].map((item) => (
                <button 
                  key={item.id}
                  onClick={() => onNavigate(item.id === 'feed' ? 'hub' : item.id)}
                  className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden ${
                    item.active 
                    ? 'bg-gradient-to-r from-cyan-900/40 to-transparent text-white border-l-2 border-cyan-500' 
                    : 'text-zinc-500 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${item.active ? 'text-cyan-400' : 'text-zinc-500 group-hover:text-white'}`} />
                  <span className="hidden md:block font-bold tracking-wide text-sm">{item.label}</span>
                  {item.active && <div className="absolute inset-0 bg-cyan-400/5 blur-md"></div>}
                </button>
              ))}
           </nav>

           <div className="px-6 mt-auto">
             <div className="bg-gradient-to-br from-purple-900/20 to-black border border-purple-500/20 rounded-2xl p-4">
               <h4 className="text-xs font-bold text-purple-400 uppercase mb-2">MSR Status</h4>
               <div className="text-2xl font-mono font-bold">{profile.reputation}</div>
               <div className="w-full h-1 bg-zinc-800 rounded-full mt-2 overflow-hidden">
                 <div className="h-full bg-purple-500 w-[60%]"></div>
               </div>
             </div>
           </div>
        </div>

        {/* CENTER FEED (The "Wall") */}
        <div className="flex-1 overflow-y-auto custom-scrollbar pointer-events-auto relative">
           {/* Feed Header / Composer */}
           <div className="max-w-3xl mx-auto pt-8 pb-4 px-4">
              <div className="bg-zinc-900/60 backdrop-blur-md border border-white/10 rounded-2xl p-4 mb-8 shadow-lg">
                <div className="flex gap-4">
                  <div className="w-10 h-10 bg-zinc-800 rounded-full shrink-0"></div>
                  <input type="text" placeholder="¿Qué estás construyendo hoy en el multiverso?" className="bg-transparent w-full outline-none text-white placeholder-zinc-500" />
                </div>
                <div className="flex justify-between items-center mt-4 pt-4 border-t border-white/5">
                  <div className="flex gap-4 text-cyan-500">
                    <Box className="w-5 h-5 cursor-pointer hover:text-cyan-300" />
                    <Play className="w-5 h-5 cursor-pointer hover:text-cyan-300" />
                  </div>
                  <button className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-1.5 rounded-full text-sm font-bold tracking-wide transition-all shadow-[0_0_15px_rgba(34,211,238,0.3)]">
                    PUBLICAR
                  </button>
                </div>
              </div>

              {/* Posts Stream */}
              <div className="space-y-6 pb-20">
                {FEED_POSTS.map(post => (
                  <div key={post.id} className="bg-zinc-900/80 backdrop-blur-md border border-zinc-800 rounded-2xl overflow-hidden hover:border-cyan-500/30 transition-all duration-300 group">
                    {/* Header */}
                    <div className="p-4 flex justify-between items-start">
                      <div className="flex gap-3">
                         <div className="w-10 h-10 rounded-full bg-gradient-to-br from-zinc-700 to-black border border-white/10"></div>
                         <div>
                           <div className="flex items-center gap-2">
                             <h3 className="font-bold text-white text-sm hover:underline cursor-pointer">{post.author}</h3>
                             <span className={`text-[9px] px-1.5 py-0.5 rounded border ${
                               post.role === 'AI GUARDIAN' ? 'bg-purple-500/20 text-purple-300 border-purple-500/50' : 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                             }`}>{post.role}</span>
                           </div>
                           <p className="text-xs text-zinc-500">{post.time}</p>
                         </div>
                      </div>
                      <button className="text-zinc-500 hover:text-white"><MoreHorizontal className="w-5 h-5" /></button>
                    </div>

                    {/* Content */}
                    <div className="px-4 pb-2">
                      <p className="text-zinc-300 text-sm leading-relaxed mb-3">{post.content}</p>
                    </div>

                    {/* Media / 3D Preview */}
                    {post.image && (
                      <div className="relative w-full h-64 bg-black overflow-hidden group/media cursor-pointer" onClick={onEnterImmersion}>
                         <img src={post.image} className="w-full h-full object-cover opacity-80 group-hover/media:opacity-100 group-hover/media:scale-105 transition-all duration-700" alt="content" />
                         
                         {post.has3D && (
                           <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover/media:opacity-100 transition-opacity backdrop-blur-[2px]">
                              <button className="bg-white/10 hover:bg-cyan-500 border border-white/20 hover:border-cyan-400 text-white px-6 py-3 rounded-full flex items-center gap-2 backdrop-blur-md transition-all transform scale-90 group-hover/media:scale-100 shadow-[0_0_30px_rgba(34,211,238,0.4)]">
                                <Box className="w-5 h-5" />
                                <span className="font-orbitron font-bold tracking-wider text-sm">ENTER 3D SPACE</span>
                              </button>
                           </div>
                         )}
                         
                         <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur px-2 py-1 rounded text-[10px] font-mono text-cyan-400 border border-cyan-500/30">
                            XR-READY
                         </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="p-4 border-t border-zinc-800 flex justify-between items-center text-zinc-400">
                       <button className="flex items-center gap-2 text-xs hover:text-red-400 transition-colors group/btn">
                          <Heart className="w-4 h-4 group-hover/btn:scale-110 transition-transform" /> {post.likes}
                       </button>
                       <button className="flex items-center gap-2 text-xs hover:text-cyan-400 transition-colors">
                          <MessageSquare className="w-4 h-4" /> {post.comments}
                       </button>
                       <button className="flex items-center gap-2 text-xs hover:text-white transition-colors">
                          <Share2 className="w-4 h-4" /> Share
                       </button>
                    </div>
                  </div>
                ))}
                
                {/* Immersion Prompt */}
                <div className="py-8 text-center">
                    <button 
                        onClick={onEnterImmersion}
                        className="group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-transparent font-orbitron border border-cyan-500/30 rounded-full hover:border-cyan-400 hover:bg-cyan-950/30"
                    >
                        <span className="absolute w-full h-full -mt-1 rounded-lg opacity-30 bg-gradient-to-b from-transparent via-transparent to-cyan-500"></span>
                        <span className="relative flex items-center gap-3">
                             <Globe className="w-5 h-5 animate-spin-slow" />
                             EXPLORE THE FULL MULTIVERSE
                        </span>
                    </button>
                </div>
              </div>
           </div>
        </div>

        {/* RIGHT SIDEBAR (Widgets) */}
        <div className="hidden xl:block w-80 bg-black/40 backdrop-blur-md border-l border-white/5 py-6 px-4 pointer-events-auto">
            {/* Isabella Widget */}
            <div className="bg-gradient-to-b from-orange-950/20 to-black border border-orange-500/20 rounded-2xl p-4 mb-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-orange-500/10 rounded-full blur-2xl"></div>
                <div className="flex items-center gap-3 mb-3 relative z-10">
                    <div className="w-10 h-10 rounded-full border border-orange-500/40 p-0.5">
                        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop" className="w-full h-full rounded-full object-cover" alt="AI" />
                    </div>
                    <div>
                        <h4 className="font-orbitron font-bold text-orange-100 text-sm">ISABELLA</h4>
                        <p className="text-[10px] text-orange-400 animate-pulse">Waiting for input...</p>
                    </div>
                </div>
                <p className="text-zinc-400 text-xs italic mb-3">"Los nodos del mercado están activos hoy. ¿Deseas ver las últimas parcelas disponibles?"</p>
                <button onClick={() => onNavigate('hub')} className="w-full bg-orange-900/30 hover:bg-orange-800/50 border border-orange-500/30 text-orange-200 text-xs py-2 rounded-lg transition-colors uppercase tracking-wider">
                    Consultar Oráculo
                </button>
            </div>

            {/* Trending */}
            <div className="mb-6">
                <h3 className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-4">Trending in TAMV</h3>
                <div className="space-y-3">
                    {['#DreamSpaceContest', '#DekateotlVote', '#CyberFashion', '#MSRMining'].map(tag => (
                        <div key={tag} className="flex justify-between items-center group cursor-pointer">
                            <span className="text-zinc-300 text-sm group-hover:text-cyan-400 transition-colors">{tag}</span>
                            <span className="text-[10px] text-zinc-600">2.4k posts</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Online Friends */}
            <div>
                <h3 className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-4">Citizens Online</h3>
                <div className="flex gap-2">
                    {[1,2,3,4,5].map(i => (
                        <div key={i} className="w-10 h-10 rounded-full bg-zinc-800 border-2 border-black relative cursor-pointer hover:scale-110 transition-transform hover:border-cyan-500">
                             <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-black rounded-full"></div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default SocialHub;