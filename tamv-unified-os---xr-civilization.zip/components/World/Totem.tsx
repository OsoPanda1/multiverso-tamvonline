import React, { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { ZoneData } from '../../types';

interface TotemProps {
  data: ZoneData;
  onInteract: (id: string) => void;
}

const Totem: React.FC<TotemProps> = ({ data, onInteract }) => {
  const meshRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  // Clean up cursor state when component unmounts
  useEffect(() => {
    return () => {
      document.body.style.cursor = 'auto';
    };
  }, []);

  useFrame((state) => {
    if (meshRef.current) {
      // Continuous idle rotation
      meshRef.current.rotation.y += 0.005;
      
      // Smooth scale transition based on hover state
      // Use data.scale if available, otherwise default to 1
      const baseScale = data.scale || 1;
      const targetScale = hovered ? baseScale * 1.15 : baseScale;
      
      meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }
  });

  return (
    <group 
      ref={meshRef} 
      position={new THREE.Vector3(...data.position)}
      onPointerOver={(e) => { 
        e.stopPropagation(); // Prevent hitting objects behind this one
        setHovered(true); 
        document.body.style.cursor = 'pointer'; 
      }}
      onPointerOut={(e) => { 
        setHovered(false); 
        document.body.style.cursor = 'auto'; 
      }}
      onClick={(e) => {
        e.stopPropagation();
        onInteract(data.id);
      }}
    >
      {/* Base Geometry */}
      <mesh position={[0, 0.5, 0]}>
        <boxGeometry args={[0.8, 4, 0.8]} />
        <meshStandardMaterial 
          color={data.color} 
          roughness={0.2} 
          metalness={0.8}
          emissive={data.color}
          emissiveIntensity={hovered ? 0.8 : 0.2}
        />
      </mesh>

      {/* Floating Info Label */}
      <Html position={[0, 3, 0]} center distanceFactor={10} style={{ pointerEvents: 'none' }}>
        <div 
          className={`transition-all duration-300 ${
            hovered ? 'opacity-100 transform translate-y-0 scale-110' : 'opacity-60 transform translate-y-2 scale-100'
          }`}
        >
          <div className="bg-black/70 backdrop-blur-sm border border-white/20 p-3 rounded-lg text-center min-w-[150px] shadow-[0_0_15px_rgba(0,0,0,0.5)]">
            <h3 className="text-white font-bold uppercase tracking-wider text-sm">{data.name}</h3>
            {hovered && (
              <p className="text-xs text-gray-300 mt-1 animate-in fade-in slide-in-from-top-1 duration-300">{data.description}</p>
            )}
          </div>
          <div className="w-0.5 h-8 bg-white/20 mx-auto"></div>
        </div>
      </Html>

      {/* Dynamic Light source */}
      <pointLight 
        position={[0, 2, 0]} 
        color={data.color} 
        intensity={hovered ? 4 : 2} 
        distance={8} 
        decay={2} 
      />
    </group>
  );
};

export default Totem;