import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, Float, MeshTransmissionMaterial, Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { ZoneData } from '../../types';

interface IridescentNodeProps {
  data: ZoneData;
  onInteract: (id: string) => void;
}

const IridescentNode: React.FC<IridescentNodeProps> = ({ data, onInteract }) => {
  const groupRef = useRef<THREE.Group>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Mesh>(null);
  const ring2Ref = useRef<THREE.Mesh>(null);
  const beaconRef = useRef<THREE.Mesh>(null);
  
  const [hovered, setHovered] = useState(false);

  // Animation Loop
  useFrame((state, delta) => {
    const t = state.clock.getElapsedTime();
    
    // Core Rotation & Pulse
    if (coreRef.current) {
      coreRef.current.rotation.x = Math.sin(t * 0.2) * 0.2;
      coreRef.current.rotation.y += delta * 0.2;
      
      const targetScale = hovered ? 1.2 : 1.0;
      coreRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }

    // Rings Gyroscope Animation (Tech/Magic feel)
    if (ring1Ref.current) {
        ring1Ref.current.rotation.x = t * 0.5;
        ring1Ref.current.rotation.z = Math.sin(t * 0.3) * 0.5;
    }
    if (ring2Ref.current) {
        ring2Ref.current.rotation.y = t * 0.4;
        ring2Ref.current.rotation.x = Math.cos(t * 0.2) * 0.5;
    }

    // Beacon Pulse (Vertical Light)
    if (beaconRef.current) {
        const pulse = 0.3 + Math.sin(t * 3) * 0.1;
        (beaconRef.current.material as THREE.MeshBasicMaterial).opacity = hovered ? 0.6 : pulse;
        beaconRef.current.scale.y = 1 + Math.sin(t * 2) * 0.1;
    }
  });

  return (
    <group position={new THREE.Vector3(...data.position)} ref={groupRef}>
      
      {/* 1. LIGHT BEACON (Vertical Pillar to Infinity) */}
      <mesh position={[0, 15, 0]} ref={beaconRef}>
         <cylinderGeometry args={[0.02, 0.5, 40, 16, 1, true]} />
         <meshBasicMaterial 
            color={data.color} 
            transparent 
            opacity={0.15} 
            side={THREE.DoubleSide} 
            blending={THREE.AdditiveBlending} 
            depthWrite={false}
         />
      </mesh>

      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5} floatingRange={[-0.2, 0.2]}>
        
        {/* 2. CORE CRYSTAL (The Data Storage) */}
        <mesh 
          ref={coreRef}
          onPointerOver={(e) => { e.stopPropagation(); setHovered(true); document.body.style.cursor = 'pointer'; }}
          onPointerOut={(e) => { setHovered(false); document.body.style.cursor = 'auto'; }}
          onClick={(e) => { e.stopPropagation(); onInteract(data.id); }}
        >
          {/* Octahedron for a more constructed/synthetic look */}
          <octahedronGeometry args={[1, 0]} /> 
          
          {/* HIGH FIDELITY TRANSMISSION SHADER */}
          <MeshTransmissionMaterial 
            backside
            samples={8} // High quality
            resolution={512}
            thickness={2.0}
            roughness={0.05}
            chromaticAberration={0.4}
            anisotropy={0.3}
            distortion={0.4}
            distortionScale={0.5}
            temporalDistortion={0.1}
            iridescence={1}
            iridescenceIOR={1.5}
            iridescenceThicknessRange={[0, 1400]}
            color={data.color}
            emissive={data.color}
            emissiveIntensity={hovered ? 0.6 : 0.1}
            toneMapped={true}
          />
        </mesh>

        {/* 3. TECH RINGS (Containment Field) */}
        <group>
            <mesh ref={ring1Ref}>
                <torusGeometry args={[1.4, 0.02, 16, 64]} />
                <meshStandardMaterial color="#ffffff" emissive={data.color} emissiveIntensity={0.5} metalness={1} roughness={0.1} />
            </mesh>
            <mesh ref={ring2Ref} rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[1.7, 0.015, 16, 64]} />
                <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.2} metalness={1} roughness={0.1} />
            </mesh>
        </group>

        {/* 4. INTERIOR PARTICLES */}
        <Sparkles count={25} scale={2} size={3} speed={0.4} opacity={0.5} color="#fff" />

        {/* 5. CORE LIGHT SOURCE */}
        <pointLight color={data.color} intensity={hovered ? 6 : 3} distance={10} decay={2} />

        {/* 6. HOLOGRAPHIC LABEL UI */}
        <Html position={[0, -2.5, 0]} center distanceFactor={15} style={{pointerEvents:'none'}}>
          <div className={`transition-all duration-500 ease-out ${hovered ? 'opacity-100 translate-y-0 scale-110' : 'opacity-70 translate-y-4 scale-90'}`}>
             <div className="flex flex-col items-center gap-2">
                {/* Connecting Line */}
                <div className="w-px h-12 bg-gradient-to-b from-transparent via-cyan-500 to-cyan-500/50 mb-1 shadow-[0_0_10px_cyan]"></div>
                
                {/* Badge Container */}
                <div 
                    className="relative bg-black/80 backdrop-blur-xl border border-white/10 px-6 py-3 rounded-sm shadow-[0_0_40px_rgba(0,0,0,0.8)] flex flex-col items-center group"
                    style={{ borderColor: `${data.color}60`, boxShadow: `0 0 25px ${data.color}30` }}
                >
                    <div className="flex items-center gap-2 mb-1">
                        <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{backgroundColor: data.color, boxShadow: `0 0 10px ${data.color}`}}></div>
                        <span className="text-white text-xs font-bold tracking-[0.25em] whitespace-nowrap font-orbitron uppercase drop-shadow-md">{data.name}</span>
                    </div>
                    {hovered && (
                        <div className="overflow-hidden h-auto max-h-20 transition-all">
                             <span className="text-[9px] text-gray-300 font-rajdhani tracking-wider uppercase block text-center">
                                {data.category} NODE
                            </span>
                             <div className="w-full h-px bg-gradient-to-r from-transparent via-white/50 to-transparent my-1"></div>
                        </div>
                    )}
                    
                    {/* Tech UI Corners */}
                    <div className="absolute top-0 left-0 w-2 h-2 border-t border-l" style={{borderColor: data.color}}></div>
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r" style={{borderColor: data.color}}></div>
                    <div className="absolute top-0 right-0 w-2 h-2 border-t border-r" style={{borderColor: data.color}}></div>
                    <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l" style={{borderColor: data.color}}></div>
                </div>
             </div>
          </div>
        </Html>

      </Float>
      
      {/* 7. GROUND ANCHOR / ENERGY RIPPLE */}
      <mesh position={[0, -data.position[1] + 0.1, 0]} rotation={[-Math.PI/2, 0, 0]}>
        <ringGeometry args={[0.5, 2.5, 64]} />
        <meshBasicMaterial 
            color={data.color} 
            transparent 
            opacity={0.1} 
            side={THREE.DoubleSide} 
            blending={THREE.AdditiveBlending} 
        />
      </mesh>
    </group>
  );
};

export default IridescentNode;