import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, Float, Sparkles as DreiSparkles, MeshTransmissionMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { Send, X } from 'lucide-react';
import { sendMessageToIsabella, startIsabellaSession, IsabellaResponse } from '../../services/geminiService';
import { ChatMessage, ThreatLevel } from '../../types';
import { useExperience } from '../../contexts/ExperienceContext';

interface IsabellaOracleProps {
  apiKey: string;
  reactionTrigger?: number;
  onNavigate: (id: string) => void;
}

const ISABELLA_AVATAR_URL = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop";

const IsabellaOracle: React.FC<IsabellaOracleProps> = ({ apiKey, reactionTrigger, onNavigate }) => {
  const groupRef = useRef<THREE.Group>(null);
  const avatarGroupRef = useRef<THREE.Group>(null);
  const bodyMeshRef = useRef<THREE.Group>(null); // Ref for independent body breathing
  
  // Refs for materials to animate color without re-renders
  const headCoreMatRef = useRef<THREE.MeshBasicMaterial>(null);
  const bodyCoreMatRef = useRef<THREE.MeshBasicMaterial>(null);
  const shellMatRef = useRef<any>(null); // MeshTransmissionMaterial ref

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);
  
  const { state, dispatch } = useExperience();

  // Colors
  const COLOR_IDLE = new THREE.Color('#ffb703');
  const COLOR_REACT = new THREE.Color('#ffffff');
  const COLOR_CORE_BODY = new THREE.Color('#fb8500');
  
  // Governance Colors
  const COLOR_CRITICAL = new THREE.Color('#ff0000');
  const COLOR_ELEVATED = new THREE.Color('#ff5500');

  const handleOSResponse = (response: IsabellaResponse) => {
    setMessages(prev => [...prev, { role: 'model', text: response.reply, timestamp: Date.now() }]);
    response.commands.forEach(cmd => {
        console.log(`[ISABELLA CORE] Executing: ${cmd.type}`, cmd);
        switch (cmd.type) {
            case 'NAVIGATE': onNavigate(cmd.payload); break;
            case 'SET_MODE': dispatch({ type: 'SET_MODE', mode: cmd.payload as any }); break;
            case 'SET_THEME': dispatch({ type: 'SET_THEME', theme: cmd.payload as any }); break;
            case 'SET_AUDIO_PRESET': dispatch({ type: 'SET_AUDIO_PRESET', preset: cmd.payload as any }); break;
            case 'SET_XR_SCENE': dispatch({ type: 'SET_XR_SCENE', scene: cmd.payload as any }); break;
            case 'SET_INTENSITY': if (cmd.numericPayload !== undefined) dispatch({ type: 'SET_INTENSITY', intensity: cmd.numericPayload }); break;
            case 'SET_THREAT_LEVEL': dispatch({ type: 'SET_THREAT_LEVEL', level: cmd.payload as any }); break;
        }
    });
  };

  useFrame((_, delta) => {
    const t = _.clock.getElapsedTime();
    
    // 1. Float Animation (Group Level)
    if (groupRef.current) {
      groupRef.current.position.y = Math.sin(t * 0.5) * 0.2;
    }

    // 2. Reaction Logic
    const isReacting = reactionTrigger && (Date.now() - reactionTrigger < 1500);
    const activeState = isReacting || isLoading;
    const isCritical = state.threatLevel === ThreatLevel.CRITICAL;

    // 3. Avatar Global Animation (Spin)
    if (avatarGroupRef.current) {
        // Spin Speed increases on activity or critical threat
        let targetSpeed = activeState ? 10.0 : 0.3;
        if (isCritical) targetSpeed = 5.0 + Math.sin(t * 20) * 5.0; // Glitchy movement

        avatarGroupRef.current.rotation.y += targetSpeed * delta;
    }

    // 4. Body Breathing (Chest expansion simulation)
    if (bodyMeshRef.current) {
        const breathSpeed = activeState ? 8 : 2; 
        const breathAmp = activeState ? 0.08 : 0.03;
        const breathCycle = Math.sin(t * breathSpeed) * breathAmp + 1;
        
        // Scale X and Z for chest expansion
        bodyMeshRef.current.scale.lerp(new THREE.Vector3(breathCycle, 1, breathCycle), 0.1);
    }

    // 5. Material Animation (Color & Distortion)
    let targetCoreColor = activeState ? COLOR_REACT : COLOR_IDLE;
    let targetBodyColor = activeState ? COLOR_REACT : COLOR_CORE_BODY;

    if (isCritical) {
        targetCoreColor = COLOR_CRITICAL;
        targetBodyColor = COLOR_CRITICAL;
    } else if (state.threatLevel === ThreatLevel.ELEVATED) {
        targetCoreColor = COLOR_ELEVATED;
        targetBodyColor = COLOR_ELEVATED;
    }

    if (headCoreMatRef.current) headCoreMatRef.current.color.lerp(targetCoreColor, 0.1);
    if (bodyCoreMatRef.current) bodyCoreMatRef.current.color.lerp(targetBodyColor, 0.1);

    if (shellMatRef.current) {
        // Increase chromatic aberration when active or critical (glitch effect)
        const targetChrom = activeState ? 1.5 : (isCritical ? 1.0 : 0.4);
        shellMatRef.current.chromaticAberration = THREE.MathUtils.lerp(shellMatRef.current.chromaticAberration, targetChrom, 0.05);
        shellMatRef.current.color.lerp(isCritical ? COLOR_CRITICAL : new THREE.Color('#ffffff'), 0.05);
    }
  });

  const handleToggle = async () => {
    const newState = !isOpen;
    setIsOpen(newState);
    if (newState && !hasInitialized) {
      setIsLoading(true);
      try {
        const response = await startIsabellaSession();
        handleOSResponse(response);
        setHasInitialized(true);
      } catch (e) {
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;
    const userMsg = inputValue;
    setInputValue('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg, timestamp: Date.now() }]);
    setIsLoading(true);
    try {
      const response = await sendMessageToIsabella(userMsg);
      handleOSResponse(response);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <group position={[0, 0, 0]} ref={groupRef}>
      <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
        <group 
            ref={avatarGroupRef}
            onClick={handleToggle}
            onPointerOver={() => document.body.style.cursor = 'pointer'}
            onPointerOut={() => document.body.style.cursor = 'auto'}
        >
             {/* --- LAYERED HEAD (The Mind - High Clarity) --- */}
             <group position={[0, 1.6, 0]}>
                {/* Inner Core */}
                <mesh>
                    <sphereGeometry args={[0.14, 32, 32]} />
                    <meshBasicMaterial ref={headCoreMatRef} color="#ffb703" toneMapped={false} />
                </mesh>
                {/* Outer Shell - Diamond/Glass-like */}
                <mesh>
                    <sphereGeometry args={[0.25, 32, 32]} />
                    <MeshTransmissionMaterial 
                        ref={shellMatRef}
                        backside
                        samples={6}
                        thickness={0.2}
                        chromaticAberration={0.5}
                        anisotropy={0.3}
                        distortion={0.3}
                        distortionScale={0.3}
                        iridescence={1}
                        iridescenceIOR={1.8}
                        clearcoat={1}
                        color="#ffffff"
                    />
                </mesh>
             </group>

             {/* --- LAYERED BODY (The Soul - Frosted/Organic) --- */}
             <group position={[0, 0.8, 0]} ref={bodyMeshRef}>
                {/* Inner Core */}
                <mesh>
                    <capsuleGeometry args={[0.1, 0.8, 8, 16]} />
                    <meshBasicMaterial ref={bodyCoreMatRef} color="#fb8500" toneMapped={false} />
                </mesh>
                {/* Outer Shell - Thicker, slightly frosted */}
                <mesh>
                    <capsuleGeometry args={[0.22, 1.0, 16, 32]} />
                    <MeshTransmissionMaterial 
                        backside
                        samples={6}
                        thickness={0.8}
                        chromaticAberration={0.2}
                        anisotropy={0.1}
                        distortion={0.6}
                        distortionScale={0.3}
                        temporalDistortion={0.2}
                        roughness={0.15}
                        color="#ffffff"
                    />
                </mesh>
             </group>
            
            {/* --- HALO RING (Divinity Symbol) --- */}
            <mesh position={[0, 1, 0.15]} rotation={[0,0,0]}>
                <torusGeometry args={[0.08, 0.005, 16, 32]} />
                <meshBasicMaterial color="#ffffff" transparent opacity={0.6} />
            </mesh>
        </group>

        {/* --- AURA PARTICLES --- */}
        <group position={[0, 1, 0]}>
            <DreiSparkles 
                count={60} 
                scale={3} 
                size={2.5} 
                speed={0.4} 
                opacity={0.6} 
                color={state.threatLevel === ThreatLevel.CRITICAL ? "#ff0000" : "#ffb703"} 
            />
            <pointLight 
                position={[0, 0.5, 0.5]} 
                intensity={2.5} 
                color={state.threatLevel === ThreatLevel.CRITICAL ? "#ff0000" : "#ffb703"} 
                distance={6} 
                decay={2} 
            />
        </group>
      </Float>

      {!isOpen && (
        <Html position={[0, 2.6, 0]} center>
          <div className="pointer-events-none flex flex-col items-center gap-2">
            <div className={`w-12 h-12 rounded-full border-2 shadow-[0_0_15px_rgba(255,165,0,0.5)] overflow-hidden bg-black transition-colors duration-500 ${
                state.threatLevel === ThreatLevel.CRITICAL ? 'border-red-500 shadow-red-900' : 'border-orange-400/50'
            }`}>
                <img src={ISABELLA_AVATAR_URL} alt="Isabella" className="w-full h-full object-cover opacity-90" />
            </div>
            
            <div className={`backdrop-blur-md border px-4 py-1.5 rounded-full flex items-center gap-2 shadow-[0_0_20px_rgba(255,170,85,0.2)] transition-colors duration-500 ${
                state.threatLevel === ThreatLevel.CRITICAL ? 'bg-red-900/60 border-red-500/80' : 'bg-black/60 border-orange-500/30'
            }`}>
               <div className={`w-2 h-2 rounded-full animate-pulse ${state.threatLevel === ThreatLevel.CRITICAL ? 'bg-red-500' : 'bg-orange-400'}`}></div>
               <span className={`text-xs font-bold tracking-[0.2em] uppercase font-orbitron ${state.threatLevel === ThreatLevel.CRITICAL ? 'text-red-100' : 'text-orange-100'}`}>Isabella</span>
            </div>
          </div>
        </Html>
      )}

      {isOpen && (
        <Html position={[1.5, 1.5, 0]} transform distanceFactor={4}>
          <div className="w-[400px] h-[550px] bg-black/90 backdrop-blur-xl border border-orange-500/40 rounded-3xl flex flex-col overflow-hidden shadow-[0_0_80px_rgba(255,165,0,0.25)]">
            
            <div className="p-5 border-b border-orange-500/30 flex justify-between items-center bg-gradient-to-r from-orange-950/50 to-transparent">
              <div className="flex items-center gap-4">
                <div className="relative">
                    <div className="w-14 h-14 rounded-full border-2 border-orange-400/60 shadow-[0_0_20px_rgba(255,165,0,0.4)] overflow-hidden">
                        <img src={ISABELLA_AVATAR_URL} alt="Isabella Villaseñor" className="w-full h-full object-cover" />
                    </div>
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-black rounded-full"></div>
                </div>
                
                <div>
                    <h3 className="text-orange-50 font-bold uppercase tracking-widest text-sm font-orbitron">Isabella Villaseñor</h3>
                    <p className="text-[10px] text-orange-400/80 font-mono tracking-wider">AI ORACLE // TAMV PROTECTOR</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-orange-400 hover:text-white transition-colors p-2 hover:bg-white/5 rounded-full">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-5 custom-scrollbar bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-orange-900/10 via-transparent to-transparent">
              {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   {msg.role === 'model' && (
                       <img src={ISABELLA_AVATAR_URL} className="w-8 h-8 rounded-full border border-orange-500/30 mr-2 mt-1 object-cover" alt="AI" />
                   )}
                  <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed shadow-lg ${
                    msg.role === 'user' 
                      ? 'bg-zinc-800 text-white border border-zinc-700 rounded-tr-sm' 
                      : 'bg-gradient-to-br from-orange-950/80 to-black text-orange-50 border border-orange-500/20 rounded-tl-sm'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start items-center gap-2">
                   <img src={ISABELLA_AVATAR_URL} className="w-8 h-8 rounded-full border border-orange-500/30 object-cover opacity-70" alt="AI" />
                  <div className="flex gap-1 items-center bg-orange-900/20 px-4 py-3 rounded-2xl border border-orange-500/10">
                    <div className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-bounce delay-150"></div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-orange-500/20 bg-black/80 backdrop-blur-md">
              <div className="flex gap-3 relative">
                <input 
                  type="text" 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Habla con Isabella..."
                  className="flex-1 bg-zinc-900/80 border border-zinc-700 hover:border-orange-500/50 focus:border-orange-500 rounded-xl px-4 py-3 text-white text-sm focus:outline-none transition-all placeholder-zinc-600 shadow-inner"
                />
                <button 
                  onClick={handleSend}
                  disabled={isLoading}
                  className="bg-gradient-to-r from-orange-700 to-amber-700 hover:from-orange-600 hover:to-amber-600 text-white px-5 rounded-xl disabled:opacity-50 transition-all shadow-lg hover:shadow-orange-500/20 flex items-center justify-center transform hover:scale-105 active:scale-95"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <p className="text-[9px] text-zinc-600 text-center mt-2 font-mono">SECURED BY MSR ENCRYPTION LAYER</p>
            </div>
          </div>
        </Html>
      )}
    </group>
  );
};

export default IsabellaOracle;