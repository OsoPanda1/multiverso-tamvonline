import React, { useRef, useState, useMemo, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Stars, Environment, Float, Cloud, Lightformer, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise, ChromaticAberration, TiltShift, ToneMapping } from '@react-three/postprocessing';
import * as THREE from 'three';
import IsabellaOracle from './IsabellaOracle';
import IridescentNode from './IridescentNode';
import MediaCarousel from './MediaCarousel';
import MarketInterface from '../UI/MarketInterface';
import GovernanceInterface from '../UI/GovernanceInterface';
import WalletOverlay from '../UI/WalletOverlay';
import TutorialOverlay from '../UI/TutorialOverlay';
import CrystalDock from '../UI/CrystalDock';
import SocialHub from '../UI/SocialHub';
import { playIsabellaGreeting, playIsabellaContextualCue } from '../../services/geminiService';
import { KAOS } from '../../services/kaosAudio';
import { ZoneData, ThreatLevel, DimensionType, ViewMode } from '../../types';
import { useExperience } from '../../contexts/ExperienceContext';

interface TamvWorldProps {
  apiKey: string;
  showTutorial: boolean;
  onTutorialComplete: () => void;
  userProfile: any;
  viewMode: ViewMode;
  onSetViewMode: (mode: ViewMode) => void;
}

// GENERATE MULTIVERSE ZONES
const generateZones = (): ZoneData[] => {
  const zones: ZoneData[] = [
    {
        id: 'market',
        name: 'Distrito Financiero',
        dimension: 'FINANCIAL',
        category: 'ECONOMY',
        description: 'Mercado de Trueque & Activos Digitales',
        position: [12, 4, 4],
        color: '#fbbf24', // Amber/Gold
        scale: 1.2
    },
    {
        id: 'academy',
        name: 'Neo-Academia',
        dimension: 'KNOWLEDGE',
        category: 'KNOWLEDGE',
        description: 'Biblioteca Universal & DevHub',
        position: [-12, 5, -4],
        color: '#34d399', // Emerald
        scale: 1.1
    },
    {
        id: 'sanctuary',
        name: 'Dekateotl Core',
        dimension: 'SPIRITUAL',
        category: 'SYSTEM',
        description: 'Gobernanza & Apelaciones',
        position: [0, 9, -14],
        color: '#a78bfa', // Violet
        scale: 1.5
    },
    {
        id: 'dreamspace',
        name: 'DreamSpace Node',
        dimension: 'CREATIVE',
        category: 'CREATIVE',
        description: 'Zona de Creación Libre XR',
        position: [0, 6, 12],
        color: '#f472b6', // Pink
        scale: 1.0
    },
    {
        id: 'profile',
        name: 'ID Nexus',
        dimension: 'NEXUS',
        category: 'SYSTEM',
        description: 'Gestión de Ciudadanía',
        position: [8, 0, 8],
        color: '#22d3ee', // Cyan
        scale: 0.9
    }
  ];

  return zones;
};

// --- AUDIO LISTENER UPDATE COMPONENT ---
const KaosAudioListener = () => {
    const { camera } = useThree();
    useFrame(() => {
        KAOS.updateListener(camera.position, camera.quaternion);
    });
    return null;
}

// --- MULTIVERSE SKYBOX & LIGHTING ---
const MultiverseEnvironment = ({ activeZone, zones }: { activeZone: string | null, zones: ZoneData[] }) => {
  const { state } = useExperience();
  
  // Determine current dimension
  const currentDimension: DimensionType = activeZone 
    ? (zones.find(z => z.id === activeZone)?.dimension || 'NEXUS')
    : 'NEXUS';

  let skyColor = "#050505";
  let fogColor = "#020205";
  
  // Dynamic Environment Colors based on state
  if (state.threatLevel === ThreatLevel.CRITICAL) {
      skyColor = "#2a0000";
      fogColor = "#1a0000";
  } else {
      switch (currentDimension) {
          case 'FINANCIAL': skyColor = "#1a1205"; fogColor = "#080500"; break;
          case 'SPIRITUAL': skyColor = "#100520"; fogColor = "#05000a"; break;
          case 'KNOWLEDGE': skyColor = "#001a10"; fogColor = "#000a05"; break;
          case 'CREATIVE': skyColor = "#1a0510"; fogColor = "#0a0005"; break;
          default: skyColor = "#02040a"; fogColor = "#010205"; break;
      }
  }

  return (
    <group>
        <color attach="background" args={[skyColor]} />
        <fogExp2 attach="fog" args={[fogColor, 0.015]} />
        
        {/* Advanced Environment Map for Reflections */}
        {/* We use Lightformers to create "Studio Lighting" effects on the glass nodes */}
        <Environment resolution={512} frames={Infinity} blur={0.8}>
            <group rotation={[0, 0, 1]}>
                {/* Ceiling Ring */}
                <Lightformer form="ring" intensity={2} rotation-x={Math.PI / 2} position={[0, 5, -9]} scale={[10, 10, 1]} />
                {/* Side Panels for metallic glint */}
                <Lightformer form="rect" intensity={5} position={[-5, 0, -10]} scale={[10, 5, 1]} target={[0, 0, 0]} />
                <Lightformer form="rect" intensity={2} position={[5, 0, -10]} scale={[10, 5, 1]} target={[0, 0, 0]} />
                {/* Overhead critical light */}
                <Lightformer form="circle" color={state.threatLevel === 'CRITICAL' ? '#ff0000' : '#ffffff'} intensity={1} scale={5} position={[0, 10, 0]} target={[0, 0, 0]} />
            </group>
        </Environment>

        <Stars radius={150} depth={50} count={9000} factor={4} saturation={0.5} fade speed={0.5} />
        
        {/* Volumetric Clouds for Atmosphere Depth */}
        <Cloud opacity={0.08} speed={0.1} width={60} depth={10} segments={20} position={[0, -20, -20]} color={fogColor} />
        <Cloud opacity={0.05} speed={0.15} width={40} depth={5} segments={10} position={[20, 10, -30]} color={fogColor} />
        
        {/* Floating Digital Dust / Motes */}
        <Sparkles count={500} scale={50} size={1.5} speed={0.2} opacity={0.3} color="#aaddff" />
    </group>
  );
};

// --- CUSTOM SHADER INFINITE FLOOR ---
const MatrixFloor = () => {
  const matRef = useRef<THREE.ShaderMaterial>(null!);
  const { state } = useExperience();

  const palette = useMemo(() => {
    if (state.threatLevel === ThreatLevel.CRITICAL) {
         return { grid: new THREE.Color('#ff0000'), glow: new THREE.Color('#550000') };
    }
    switch (state.theme) {
        case 'golden_hour': return { grid: new THREE.Color('#d97706'), glow: new THREE.Color('#b45309') };
        case 'ritual': return { grid: new THREE.Color('#a855f7'), glow: new THREE.Color('#7e22ce') };
        case 'dark': return { grid: new THREE.Color('#10b981'), glow: new THREE.Color('#047857') };
        default: return { grid: new THREE.Color('#06b6d4'), glow: new THREE.Color('#0891b2') };
    }
  }, [state.theme, state.threatLevel]);

  useFrame((clock) => {
    if (!matRef.current) return;
    matRef.current.uniforms.uTime.value = clock.clock.elapsedTime;
    // Smooth color transition
    matRef.current.uniforms.uGridColor.value.lerp(palette.grid, 0.05);
    matRef.current.uniforms.uGlowColor.value.lerp(palette.glow, 0.05);
  });

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -8, 0]} receiveShadow>
      <planeGeometry args={[300, 300]} />
      <shaderMaterial
        ref={matRef}
        transparent={true}
        depthWrite={false}
        uniforms={{
          uTime: { value: 0 },
          uGridColor: { value: palette.grid }, 
          uGlowColor: { value: palette.glow },
        }}
        vertexShader={`
          varying vec2 vUv;
          varying vec3 vPos;
          void main() {
            vUv = uv;
            vPos = position;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `}
        fragmentShader={`
          uniform float uTime;
          uniform vec3 uGridColor;
          uniform vec3 uGlowColor;
          varying vec2 vUv;
          varying vec3 vPos;

          void main() {
            // Grid Calculation
            vec2 gridUV = vUv * 150.0; // Grid Density
            
            // Calculate derivatives for anti-aliasing
            vec2 deriv = fwidth(gridUV);
            
            // SAFEGUARD: Add epsilon to avoid division by zero (Warning X4008)
            vec2 grid = abs(fract(gridUV - 0.5) - 0.5) / (deriv + 0.0001);
            
            float line = min(grid.x, grid.y);
            float alpha = 1.0 - min(line, 1.0);

            // Circular Horizon Mask (Fade out at distance)
            float dist = distance(vUv, vec2(0.5));
            float mask = smoothstep(0.48, 0.1, dist);

            // Digital Pulse (Scanline effect)
            float scan = smoothstep(0.0, 0.4, sin(vUv.y * 5.0 + uTime * 0.2) + sin(vUv.x * 3.0 - uTime * 0.1));
            
            // Mix Colors
            vec3 color = mix(uGlowColor * 0.1, uGridColor, alpha);
            color += uGridColor * scan * 0.15; // Add scanline brightness

            // Final Output with Alpha Mask
            gl_FragColor = vec4(color, (alpha * 0.6 + scan * 0.1) * mask);
          }
        `}
      />
    </mesh>
  );
};

// --- CAMERA CONTROLLER ---
const CameraController = ({ targetPos, targetLookAt, controlsRef, viewMode }: any) => {
  const { camera } = useThree();
  const vecPos = useRef(new THREE.Vector3());
  const vecLook = useRef(new THREE.Vector3());

  useFrame((state, delta) => {
    // Cinematic Idle Animation for SOCIAL mode
    if (viewMode === 'SOCIAL') {
        const t = state.clock.getElapsedTime();
        // Slower, more majestic orbital drift
        vecPos.current.set(
            Math.sin(t * 0.05) * 28, 
            15 + Math.cos(t * 0.08) * 4, 
            Math.cos(t * 0.05) * 28 + 5
        );
        camera.position.lerp(vecPos.current, 0.02);
        camera.lookAt(0, 0, 0);
        
        if (controlsRef.current) controlsRef.current.enabled = false;
        return;
    }

    if (controlsRef.current) {
      controlsRef.current.enabled = true;
      vecPos.current.set(...targetPos);
      camera.position.lerp(vecPos.current, 2.0 * delta); // Snappier movement
      
      vecLook.current.set(...targetLookAt);
      controlsRef.current.target.lerp(vecLook.current, 2.5 * delta);
      controlsRef.current.update();
    }
  });
  return null;
}

// --- MAIN COMPONENT ---
const TamvWorld: React.FC<TamvWorldProps> = ({ apiKey, showTutorial, onTutorialComplete, userProfile, viewMode, onSetViewMode }) => {
  const [activeZone, setActiveZone] = useState<string | null>(null);
  const [camPos, setCamPos] = useState<[number, number, number]>([0, 10, 30]);
  const [camTarget, setCamTarget] = useState<[number, number, number]>([0, 0, 0]);
  const [isabellaReaction, setIsabellaReaction] = useState<number>(0);
  
  // UI State
  const [showGovernance, setShowGovernance] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [showMarket, setShowMarket] = useState(false);

  const controlsRef = useRef<any>(null);
  const { state, dispatch } = useExperience();
  const zones = useMemo(() => generateZones(), []);

  // Sync Audio
  useEffect(() => { KAOS.setPreset(state.audioPreset); }, [state.audioPreset]);
  useEffect(() => { KAOS.setVolume(state.volume); }, [state.volume]);
  useEffect(() => { KAOS.setThreatLevel(state.threatLevel); }, [state.threatLevel]);

  useEffect(() => {
    const initAudio = async () => {
        await KAOS.init();
        KAOS.playSynthesizedDrone('hub_ambience', new THREE.Vector3(0,0,0));
    };
    initAudio();
  }, [showTutorial]);

  const handleNavigate = (id: string) => {
    // If navigating from Social Mode, switch to Immersive
    if (viewMode === 'SOCIAL') {
        onSetViewMode('IMMERSIVE');
    }

    if (id === 'hub') {
        handleBackToHub();
        return;
    }

    // Toggle specific UIs
    if (id === 'profile') { setShowWallet(true); return; }
    if (id === 'sanctuary') { setShowGovernance(true); return; }
    if (id === 'market') { setShowMarket(true); return; }

    setActiveZone(id);
    const zone = zones.find(z => z.id === id);
    
    if (zone) {
      playIsabellaContextualCue(zone.name, zone.category);
      setIsabellaReaction(Date.now());
      setCamTarget([zone.position[0], zone.position[1], zone.position[2]]);
      // Get closer to the node for interaction, offset slightly
      setCamPos([zone.position[0] * 1.2, zone.position[1] + 2, zone.position[2] + 8]);
      
      let newTheme = 'cyber_aqua';
      if (zone.dimension === 'FINANCIAL') newTheme = 'golden_hour';
      if (zone.dimension === 'SPIRITUAL') newTheme = 'ritual';
      if (zone.dimension === 'KNOWLEDGE') newTheme = 'dark';
      dispatch({ type: 'SET_THEME', theme: newTheme as any });

    } else if (id === 'media') {
         setCamTarget([20, 5, 0]);
         setCamPos([20, 5, 12]);
         playIsabellaContextualCue('Galería de Medios', 'SOCIAL');
         setIsabellaReaction(Date.now());
    }
  };

  const handleBackToHub = () => {
    setActiveZone(null);
    setShowGovernance(false);
    setShowWallet(false);
    setShowMarket(false);
    setCamPos([0, 10, 30]);
    setCamTarget([0, 0, 0]);
    dispatch({ type: 'SET_THEME', theme: 'cyber_aqua' });
  };

  const isCritical = state.threatLevel === ThreatLevel.CRITICAL;

  return (
    <div className="w-full h-screen bg-black relative overflow-hidden">
      {/* 3D CANVAS */}
      <div className={`absolute inset-0 transition-all duration-1000 ${viewMode === 'SOCIAL' ? 'scale-105 opacity-80 blur-[2px]' : 'scale-100 opacity-100 blur-0'}`}>
        <Canvas 
            shadows 
            dpr={[1, 1.5]} // Performance: Scale down pixel ratio slightly for heavy shaders
            camera={{ position: [0, 10, 30], fov: 35 }} // More cinematic FOV
            gl={{ 
                antialias: false, // Let EffectComposer handle AA
                toneMapping: THREE.ACESFilmicToneMapping, 
                toneMappingExposure: 1.2,
                alpha: false,
                stencil: false,
                depth: true
            }}
        >
            <KaosAudioListener />
            <CameraController targetPos={camPos} targetLookAt={camTarget} controlsRef={controlsRef} viewMode={viewMode} />
            <MultiverseEnvironment activeZone={activeZone} zones={zones} />

            {/* Main Scene Lights */}
            <ambientLight intensity={isCritical ? 0.05 : 0.1} />
            <pointLight position={[0, 20, 0]} intensity={isCritical ? 0.5 : 1} color={isCritical ? "#ff0000" : "#aaddff"} distance={60} decay={2} />
            <spotLight position={[30, 30, 30]} angle={0.3} penumbra={1} intensity={2} castShadow color="#ffffff" />

            <IsabellaOracle apiKey={apiKey} reactionTrigger={isabellaReaction} onNavigate={handleNavigate} />
            
            {zones.map(zone => <IridescentNode key={zone.id} data={zone} onInteract={handleNavigate} />)}
            
            {(activeZone === 'media') && (
                <group position={[20, 0, 0]}>
                    <MediaCarousel items={[
                        { id: '1', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=1', title: 'Multiverse Map' },
                        { id: '2', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=2', title: 'MSR Protocol' },
                        { id: '3', type: 'IMAGE', url: 'https://picsum.photos/400/300?random=3', title: 'Avatar v2' },
                    ]} />
                </group>
            )}

            <MatrixFloor />

            {/* CINEMATIC POST PROCESSING */}
            <EffectComposer disableNormalPass>
                {/* 1. Bloom for the glowy neon look */}
                <Bloom 
                    luminanceThreshold={0.85} 
                    mipmapBlur 
                    intensity={isCritical ? 2.5 : (state.intensity * 2.0)} 
                    radius={0.6} 
                />
                
                {/* 2. Chromatic Aberration for digital lens effect */}
                <ChromaticAberration 
                    offset={new THREE.Vector2(
                        isCritical ? 0.02 : 0.003, 
                        isCritical ? 0.02 : 0.003
                    )} 
                    radialModulation={false}
                    modulationOffset={0}
                />
                
                {/* 3. Noise for texture/film grain */}
                <Noise opacity={0.05} />
                
                {/* 4. Vignette to focus eyes on center */}
                <Vignette eskil={false} offset={0.1} darkness={0.7} />
                
                {/* 5. TiltShift for miniature effect in Social Mode */}
                {viewMode === 'SOCIAL' && <TiltShift blur={0.15} />}
            </EffectComposer>

            <OrbitControls ref={controlsRef} enablePan={false} maxPolarAngle={Math.PI / 2 - 0.05} minDistance={5} maxDistance={80} enableDamping dampingFactor={0.08} />
        </Canvas>
      </div>

      {/* --- LAYER 1: SOCIAL HUB OVERLAY --- */}
      <div className={`absolute inset-0 transition-all duration-700 transform ${viewMode === 'SOCIAL' ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 -translate-y-10 pointer-events-none'}`}>
         <SocialHub profile={userProfile} onNavigate={handleNavigate} onEnterImmersion={() => onSetViewMode('IMMERSIVE')} />
      </div>

      {/* --- LAYER 2: IMMERSIVE UI DOCK --- */}
      <div className={`transition-all duration-1000 delay-300 ${viewMode === 'IMMERSIVE' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20 pointer-events-none'}`}>
          <CrystalDock onNavigate={handleNavigate} activeZone={activeZone} />
          {/* Back Button */}
          <button 
            onClick={() => { handleBackToHub(); onSetViewMode('SOCIAL'); }}
            className="fixed top-6 left-6 z-50 bg-black/40 backdrop-blur border border-white/20 text-white px-4 py-2 rounded-full font-orbitron text-xs hover:bg-white/10 transition-colors hover:border-cyan-500"
          >
             EXIT IMMERSION
          </button>
      </div>
      
      {showTutorial && <TutorialOverlay onComplete={onTutorialComplete} />}
      {showMarket && <MarketInterface onClose={handleBackToHub} />}
      {showGovernance && <GovernanceInterface onClose={handleBackToHub} userMsr={userProfile.wallet.msr} />}
      {showWallet && <WalletOverlay profile={userProfile} onClose={() => setShowWallet(false)} />}
    </div>
  );
};

export default TamvWorld;