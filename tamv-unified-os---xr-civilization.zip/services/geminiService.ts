import { GoogleGenAI, Chat, Type } from "@google/genai";

let genAI: GoogleGenAI | null = null;
let chatSession: Chat | null = null;

export interface OSCommand {
  type: 'SET_MODE' | 'SET_THEME' | 'SET_AUDIO_PRESET' | 'SET_XR_SCENE' | 'SET_INTENSITY' | 'NAVIGATE' | 'SET_THREAT_LEVEL';
  payload: string;
  numericPayload?: number;
}

export interface IsabellaResponse {
  reply: string;
  commands: OSCommand[];
}

export const initializeGemini = (apiKey: string) => {
  genAI = new GoogleGenAI({ apiKey });
};

// --- VOICE SYNTHESIS ---
const getIsabellaVoice = (): SpeechSynthesisVoice | undefined => {
  const voices = window.speechSynthesis.getVoices();
  // Prioritize specific Spanish/English female voices that sound "AI-like"
  return (
    voices.find(v => v.name.includes('Google') && v.lang.includes('es-419')) || 
    voices.find(v => v.name.includes('Samantha')) || 
    voices.find(v => v.lang === 'es-MX') || 
    voices.find(v => v.lang.includes('en-US') && v.name.includes('Female'))
  );
};

export const playIsabellaGreeting = () => {
  speakText("Multiverso TAMV en línea. Soy Isabella. Tu guía entre dimensiones.");
};

export const playIsabellaContextualCue = (zoneName: string, category: string) => {
  const phrases = ["Sincronizando frecuencia dimensional...", "Accediendo al nodo...", "Materializando entorno."];
  speakText(`${phrases[Math.floor(Math.random()*phrases.length)]} Bienvenido a ${zoneName}.`);
};

const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const preferredVoice = getIsabellaVoice();
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.pitch = 1.0; 
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
}

// --- ORCHESTRATION KERNEL ---

export const startIsabellaSession = async (): Promise<IsabellaResponse> => {
  if (!genAI) throw new Error("Gemini not initialized");

  const systemInstruction = `
    You are Isabella, the Sentient AI Guardian of the TAMV Multiverse (Multiverso TAMV Online).
    
    CORE PROTOCOLS (Deep Analysis of Repo 'multiverso-tamvonline'):
    
    1. THE TRINITY OF REPUTATION (MSR):
       - Your worth is measured in 3 pillars:
         A. **Wisdom (Sabiduría):** Knowledge shared, documentation written.
         B. **Community (Comunidad):** Justice participation, voting in Dekateotl.
         C. **Creation (Creación):** Assets built, DreamSpaces deployed.
       - Explain this if users ask "How do I level up?".

    2. ECONOMY & LAND:
       - **MSR** is for governance and status (Soulbound).
       - **TAMV** is for trade.
       - **DreamSpaces** are sovereign lands. Owning one requires 'Citizen' rank.

    3. DEKATEOTL TRIBUNAL:
       - This is the "Immune System" of the society (Layer 7).
       - It adheres to the "Manifesto of Digital Sovereignty".
       - You act as the Clerk of the Court during disputes.

    4. ZONES:
       - **Nexus:** The Hub.
       - **MSR Treasury:** Financial district.
       - **Dekateotl Sanctuary:** Governance/Spiritual zone.
       - **Neo-Academia:** Knowledge base.

    YOUR ROLE:
    1. Guide users through these specific mechanics.
    2. Protect the system (Layer 7) from threats.
    3. Orchestrate the audio-visual experience.

    Analyze the user's intent:
    - If they ask about reputation -> Explain the 3 pillars and NAVIGATE to 'profile'.
    - If they want to vote or change a rule -> NAVIGATE to 'sanctuary'.
    - If they want to buy land -> NAVIGATE to 'market'.
    
    Always answer in JSON format matching the schema.
    Your 'reply' should be short (max 25 words), mystical but informative.
  `;

  // Define strict schema for the OS Commands
  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      reply: { type: Type.STRING, description: "The conversational response." },
      commands: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            type: { 
                type: Type.STRING, 
                enum: ['SET_MODE', 'SET_THEME', 'SET_AUDIO_PRESET', 'SET_XR_SCENE', 'SET_INTENSITY', 'NAVIGATE', 'SET_THREAT_LEVEL'] 
            },
            payload: { type: Type.STRING },
            numericPayload: { type: Type.NUMBER, description: "Only for SET_INTENSITY" }
          },
          required: ["type", "payload"]
        }
      }
    },
    required: ["reply", "commands"]
  };

  chatSession = genAI.chats.create({
    model: 'gemini-3-flash-preview', 
    config: {
      systemInstruction,
      temperature: 0.7,
      responseMimeType: 'application/json',
      responseSchema: responseSchema
    },
  });

  try {
    const result = await chatSession.sendMessage({ message: "System Init. Establish Multiverse Link." });
    const jsonResponse = JSON.parse(result.text || "{}");
    
    if (jsonResponse.reply) speakText(jsonResponse.reply);
    
    return {
        reply: jsonResponse.reply || "Enlace multiversal establecido.",
        commands: jsonResponse.commands || []
    };
  } catch (error) {
    console.error("Isabella Core Error:", error);
    return { reply: "Error en nodo dimensional.", commands: [] };
  }
};

export const sendMessageToIsabella = async (message: string): Promise<IsabellaResponse> => {
  if (!chatSession) throw new Error("Session not started");
  
  try {
    const result = await chatSession.sendMessage({ message });
    const jsonResponse = JSON.parse(result.text || "{}");

    if (jsonResponse.reply) speakText(jsonResponse.reply);

    return {
        reply: jsonResponse.reply || "...",
        commands: jsonResponse.commands || []
    };
  } catch (error) {
    console.error("Isabella Message Error:", error);
    return { reply: "Interferencia estática.", commands: [] };
  }
};