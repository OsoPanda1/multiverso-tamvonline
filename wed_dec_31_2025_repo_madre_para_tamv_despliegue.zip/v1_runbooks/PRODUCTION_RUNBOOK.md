```markdown
# Runbook Operacional TAMV - Producción

Versión: 2025-12-31
Propósito: guía detallada de operación, despliegue, rollback y gestión de incidentes para el ecosistema TAMV.

1) Descripción rápida del ecosistema
- TAMV: plataforma inmersiva y sensorial 4D que ofrece renderizado 3D/4D, FX multisensorial, redes sociales inmersivas y orquestación IA por microservicios.
- Cada microservicio = célula, API clara, pruebas automáticas, observabilidad y versión independiente.

2) Contactos y on-call
- SRE lead: srez@yourdomain
- DevLead IA: ia-lead@yourdomain
- Seguridad: secops@yourdomain
- PagerDuty escalation: equipo-SRE
- GitHub CODEOWNERS: /charts/* @SRETeam /services/* @DevTeam

3) Flujos de despliegue
- CI genera imagen con tag semver y SHA.
- Staging: despliegue automático desde CI en namespace tamv-staging.
- Smoke tests: /health/ready, screenshots render mínimos, audio sync basic.
- Producción: despliegue canary o blue-green (Helm + Istio/Traefik).
- Promoción: manual approval + observability green for 15m -> promote.

4) Procedure: rollback rápido
- helm rollback render-4d-hypercube <REV> --namespace tamv-prod
- kubectl --namespace tamv-prod rollout status deployment/render-4d-hypercube

5) Incidente: latencia alta en render-4d
- Alert: p95 > 500ms o error rate > 2%
- Steps:
  1. kubectl top pods -n tamv-prod
  2. kubectl logs -n tamv-prod deploy/render-4d-hypercube --since=1h
  3. Revisar traces en Tempo
  4. Escalar réplicas o mover cargas a nodepool GPU adicionales
  5. Desactivar features con feature flags
  6. Si persists, rollback y RCA

6) Backup y Recovery - Postgres
- Snapshots diarios + WAL streaming
- Restaurar snapshot a staging, tests, luego restore prod si procede

7) Hotfix flow
- branch hotfix/* -> PR -> approval -> merge -> CI -> push image -> CD dispatch (production)

8) Checklist post-incident
- Registrar INCIDENT en tracker con timeline, RCA y ACTION ITEMS
```