```markdown
- genere las plantillas exactas (archivos .github/workflows/ci.yml, helm charts, k8s manifests) listos para subir en un PR, o
- cree el runbook detallado en formato separado y scripts de automatización (Terraform, k8s bootstrap),
```