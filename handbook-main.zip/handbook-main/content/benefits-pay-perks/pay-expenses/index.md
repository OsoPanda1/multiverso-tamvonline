# Pay and Expenses

- [Compensation](compensation/index.md)
  - [Equity FAQ](compensation/equity-faq.md)
  - [Compensation Change Approvals](compensation/compensation-change-approvals.md)
- [Invoices](invoices.md)
- [Expenses](expenses/index.md)
