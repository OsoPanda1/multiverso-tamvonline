# Submitting Expenses through Deel.com

As of 3/31/24 all reimbursements must be submitted via Airbase.

Internet, phone, and wellness should be entered as **Allowances** as these are taxable.

Co-working, desk setup, and any other reimbursements should be entered as **Reimbursements** as there are NOT taxable to teammates.

If you have any questions, please reach out to the People Team in #ask-people-team in Slack
