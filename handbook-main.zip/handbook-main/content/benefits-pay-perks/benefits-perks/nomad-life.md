# Nomad Life

Our all-remote company allows Teammates to work almost any where in the world.

### Countries where we cannot currently support employment or contracting, including on a temporary basis

We cannot support or employ candidates or teammates in any of these countries due to U.S. embargoes and sanctions. This includes work while traveling for personal reasons.

- Cuba
- Iran
- North Korea
- Sudan
- Syria
- Crimea
- China
- Russia
- Ukraine

Any questions? Contact the People team in #ask-people-team in Slack or people-ops@sourcegraph.com via email!
