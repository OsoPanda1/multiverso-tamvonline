# Engineering career development

- [Career development framework](./framework.md)
- [Successful engineers at Sourcegraph](./successful-engineers.md)
