## Bi-Weekly Status Updates

As part of socializing what teams we are doing and ensuring maximum visibility, Eng teams will send out a bi-weekly (teams may increase the frequency to weekly) status update to the #announce-engineering channel.
The DRIs for the various teams:

- **Search Suite** - [Peter Guy](https://github.com/peterguy)
- **Ship** - [JH Chabran](https://github.com/jhchabran)
- **Platform** - [thorsten](https://github.com/mrnugget)/[Ryan Phillips](https://github.com/Ryphil)
- **Cody Strat** - TPM
- **Security** - [Diego Comas](https://github.com/dcomas)
- **Cody Clients**:
  - **VS Code** - [Kalan](https://github.com/kalanchan)
  - **IntelliJ** - [Olaf Geirsson](https://github.com/olafurpg)/[Kalan](https://github.com/kalanchan)
  - **Neovim** - [teej](https://github.com/tjdevries)
- **Cody PLG** - [kevin.chen](https://github.com/chenkc805)

Key highlights from the status updates that contribute to overall company goals will also be referenced in the **The Git Down** updates.
