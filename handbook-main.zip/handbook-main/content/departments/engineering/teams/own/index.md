# Own team

## Strategy

- Vision, mission and strategy: [Own strategy](../../../../strategy-goals/strategy/own/index.md)
- Key metrics: TODO after launch!

## Contact

- For general questions or concerns, #ask-own channel or @own-team on Slack.
- For engineering support requests, customer questions, or anything else, @own-team on Slack.
- @sourcegraph/own team or [own label](https://github.com/sourcegraph/sourcegraph/issues?q=is:issue+is:open+label:own) on GitHub.

## Process

- We prioritize our work in [our planning board](https://github.com/orgs/sourcegraph/projects/216). It is the responsibility of the PM and TL to keep this updated and correct.

## Sprint planning

Our two-week sprints start every other Tuesday.
