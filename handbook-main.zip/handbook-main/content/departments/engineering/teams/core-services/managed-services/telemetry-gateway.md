# Telemetry Gateway

Please refer to the [Telemetry Gateway infrastructure (go/msp-ops/telemetry-gateway)](../../../managed-services/telemetry-gateway.md) page.
