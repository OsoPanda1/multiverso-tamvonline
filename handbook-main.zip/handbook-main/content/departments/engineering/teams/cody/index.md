# Cody team

Placeholder page for the cody team.

- [About Cody FAQ](about-cody-faq.md)

Managed Cody services:

- [Cody Gateway](cody-gateway/index.md) (cody-gateway.sourcegraph.com and cody-gateway.sgdev.org)
