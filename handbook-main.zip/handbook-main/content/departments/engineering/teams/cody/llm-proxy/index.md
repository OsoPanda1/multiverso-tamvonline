# LLM proxy

> [!WARNING] **This project has been renamed to [Cody Gateway](../cody-gateway/index.md)** - this page is only retained to help redirect old links.
