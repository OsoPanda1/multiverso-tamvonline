# Delivery Team README

Our README expands on our profile in [the company team directory](../../../../../team/index.md) and are meant to help us orient to one another.

The format, style, order, etc is up to each of us. Just make sure to include the following to the degree you feel at ease to do so; feel free to add/remove as you see fit:

- How I work
- When I work
- Where I work
- What I do
- Communication style
- Preferred learning styles
- Preferred way to receive feedback
- What kind of work do you find easiest to do when (for example, some folks write best at night or can focus more easily in the afternoon)
- Things I struggle with
- What you find enjoyable at work
- Things I love outside of work
- Other things to know about me
