# Release Team Processes

## How we work

### Planning, sync, & retro

TBD

### Support Rotation

TBD

## Issue tracking

TBD

### Backlog

These are items that we want to work on in the near future. The likely need some prioritization and additional details before they can be moved to the Ready state.

### Ready

If you have completed the ticket that you are working on and need your next task, take it from here. These items have been reviewed and are ready to be worked on.

Note: The items in here are ordered by importance where the most important issues are at the top.

### In Progress

These are items that are currently being worked on. You should only have a maximum of one development story per person listed in here! On going support stories will also show up here.

### In Review

Items in here are waiting on Customer/Internal feedback.

Examples:

- We have completed work that needs to also be confirmed and worked on by other teams.

### Done

All work on this ticket that needs to be done by the Delivery team has been successfully completed.

#team-releases
