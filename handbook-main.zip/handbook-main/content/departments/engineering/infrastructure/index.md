# Infrastructure

## Teams

- [Cloud Operations](../../../departments/cloud/index.md)
- [Core Services](../teams/core-services/index.md)
- [Developer Infrastructure](../teams/devinfra/index.md)
- [Release](../teams/release/index.md)

## OKRs

- [Infrastructure OKRs](http://go/infra-okrs)

## Documents

- [Weekly Reports Instructions](weekly-reports.md)
- [AWS Organisation management](aws.md)
- [Org-wide on-call rotation](./on-call.md)
