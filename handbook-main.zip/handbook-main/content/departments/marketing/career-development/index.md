# Marketing Career Development

## Career Development Frameworks

Our Career Development Frameworks help you understand the expectations of your role and provides a common language for you and your manager to discuss and plan your career growth. They are also an important part of our larger goal of ensuring everyone is equitably recognized for the impact they have at work, and to reduce bias in promotions and hiring.

- [Comms Career Development Framework](comms-framework.md)
- [Product Marketing Career Development Framework](product-marketing-framework.md)
