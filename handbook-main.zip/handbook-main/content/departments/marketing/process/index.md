# Marketing Processes

- [Sourcegraph Documentation](product_documentation.md)
- [Adding screenshots and recordings](adding_screenshots_screen_recording.md)
- [Messaging](messaging.md)
- [Personas](personas.md)
- [Platform positioning](positioning.md)
- [Value drivers](value-drivers.md)
- [Blog post help](blog_post_help.md)
