# Technical blog post help

Need help with your technical blog posts? DevRel is here for you! Whether it's turning ideas into reality, writing assistance, or media help, we've got you covered!

### Steps

- Create a Google Doc
- Draft what you want to write about
  - It can be bullet points, Slack convos, etc.
- Share it with the marketing-team@sourcegraph.com
- Fill out [this form](https://form.asana.com/?k=y9mrkHpWKUIK7eeZ8CEJBg&d=7195383522959) to add it to our Asana board

_From there we will be in touch and help you get published!_

### Blog posts we helped publish

- https://sourcegraph.com/blog/slow-to-simd
- https://sourcegraph.com/blog/cody-the-ai-powered-tool-helping-support-engineers-unblock-themselves
- https://sourcegraph.com/blog/cody-vscode-1-10-0-release
- https://sourcegraph.com/blog/cody-jetbrains-5-4-358-release
