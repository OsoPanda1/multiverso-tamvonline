# Phabricator vs. Sourcegraph

[Phabricator](https://www.phacility.com/phabricator/) is an all-in-one development platform that was initially built inside Facebook. Sourcegraph and Phabricator integrate well together (and offer complementary, not overlapping, features).

- [Phabricator integration with Sourcegraph](https://docs.sourcegraph.com/integration/phabricator) (Sourcegraph documentation)
