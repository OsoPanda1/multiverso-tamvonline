# Finance Processes

- [AP](ap.md)
- [AR](ar.md)
- [Collections](collections.md)
- [Collections Class Matrix](collectionsclassmatrix.md)
- [Payables](payables.md)
