# Workplace Postings

Sourcegraph is a fully remote company with no offices. We use this page to house all posters and posting you would normally find in an office space. There is a lot of values in teammates having access to this important information.
If you ever have any questions or concerns, please reach out to the people team at [people-ops@sourcegraph.com](mailto:people-ops@sourcegraph.com).

## Employment posters

- [US Federal labor law posters](https://drive.google.com/drive/folders/1xEZc7Y5pdHEoka9A4N_FI2W8biDsre0Q?usp=sharing)
- [US State specific labor law posters](https://drive.google.com/drive/folders/1q60cDDRxqZ45CfmPcXgGKaNPGBrzdoXU?usp=sharing)
- [US City specific labor law posters](https://drive.google.com/drive/folders/15axBqSxeLrT-iCl8MZ2HZoIdgc-SeQP6?usp=sharing)
- International posters coming soon

Coming soon

## LCA postings

- [LCA - 04701](https://docs.google.com/document/d/1QY8o12nKIKSnYhzL0knrP2VzThww6Um1/edit?usp=sharing&ouid=117604448966777770436&rtpof=true&sd=true)
- Historical postings (coming soon)
