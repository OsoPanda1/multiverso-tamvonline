# People & Talent Team Alignment by Department

People Partner alignment:

- Technical Success & Support, Operations, Legal, Marketing, Talent & People - Lauren Ross, Senior People Partner
- Engineering, Product & Design - Lauren Ross, Senior People Partner
- Sales - Marija Petrovic, Director, Recruiting & People-Ops
- Executive Team support, Carly Jones, VP, People & Talent
- Any critical concerns - Carly Jones, VP, People & Talent

Talent Team alignment (contact the below person and they will assign you to a Recruiter):

- Sales, TS, Support, Marketing, Ops - Marija Petrovic, Director, Recruiting & People-Ops
- Engineering, Product, Design - Devon Coords, Director, Technical Recruiting
- Exec search - Carly Jones, VP, People & Talent
