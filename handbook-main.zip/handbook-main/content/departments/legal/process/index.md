# Legal team processes

- [Contract review and signature authority policy](ContractReviewandSignatureAuthorityPolicy.md)
