The CEO Team is comprised of the [CEO](../../team/ceo/index.md) and the [Chief of Staff to the CEO](../../team/index.md#connor-obrien)

The CEO Team supports and augments the CEO helping to connect company strategy to operations to day-to-day tactical execution.

Here are a list of programs supported by the CEO Team:

- [Board Meetings](https://docs.google.com/document/d/1gPZycyHduo0OB-6PgfuMvTFx95a0rNFmWaPR7E3R7qg/edit?usp=sharing)
- [CEO Shadow Program](ceo-shadow-program.md)
