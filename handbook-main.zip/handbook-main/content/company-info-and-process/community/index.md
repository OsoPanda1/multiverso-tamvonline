# Sourcegraph community

- [Code of Conduct](code_of_conduct.md)
- [FAQ](faq.md)
- [Discord](https://discord.gg/s2qDtYGnAE)
