# Sourcegraph open source

See https://github.com/sourcegraph/sourcegraph/issues/53528#issuecomment-1594967818. Will be updated with more info soon.
