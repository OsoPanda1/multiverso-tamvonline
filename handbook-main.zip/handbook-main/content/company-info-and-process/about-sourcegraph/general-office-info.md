# Address, Phone Number, Tax ID, and other general office information

### Contact information

Address (for all mail, contracts, and paperwork): 548 Market St PMB 20739, San Francisco, CA 94104-5401

Phone number: (650) 273-5591

### Business information

Tax ID: For the Tax ID, refer to your Sourcegraph W-9.

DUNS number: `117775232`

NAICS code: `541512`

SIC code: `7373`

### Banking information

Bank Name: JPMorgan Chase Bank, N.A.

Bank Address: JPMorgan Chase New York, NY 10017

Bank Account Name: Sourcegraph, Inc.

Account Currency: USD

[Bank Detail Letter](https://drive.google.com/file/d/17KLmr_6OanWpWfr_vIY_OrxO8gdUgmB1/view?usp=sharing)

#### For ACH delivery:

Bank Routing Number: `322271627`

Account Number: `936960100`

Account Name: Sourcegraph, Inc.

#### For Wire Transfers:

Bank Routing Number: `021000021`

SWIFT Code: CHASUS33

Account Number: `936960100`

Account Name: Sourcegraph, Inc. - Receivables account
