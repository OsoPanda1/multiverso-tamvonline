# About Sourcegraph

- [**Sourcegraph.com/about**](https://sourcegraph.com/about) for information about Sourcegraph (the product and the company)
- [Sourcegraph handbook](../../index.md)
- [All-remote](../remote/index.md)
- [Asynchronous work](../communication/asynchronous-communication.md)
- [Strategy](../../strategy-goals/strategy/index.md)
- [Team](../../team/index.md)
- [Values](../values/index.md)

<div style="position: relative; padding-bottom: 56.25%; height: 0;">
  <iframe 
    src="https://www.loom.com/embed/65bb6a7ced414119ab29380f0ea93f34?sid=259da778-4f21-433a-9e4f-e4f4a0a32af4" 
    frameborder="0" 
    webkitallowfullscreen 
    mozallowfullscreen 
    allowfullscreen 
    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
  ></iframe>
</div>
