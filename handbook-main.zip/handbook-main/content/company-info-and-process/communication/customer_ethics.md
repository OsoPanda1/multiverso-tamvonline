# Customer ethics criteria

We do not knowingly work with organizations that promote violence or hate, or that conflict with our company values or ethical principles of integrity and trustworthiness in a way that harms people. If anyone thinks an organization that we are working with (or considering working with) meets this criteria, contact @sqs.
