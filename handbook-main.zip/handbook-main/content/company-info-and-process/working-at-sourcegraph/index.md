# Working at Sourcegraph

- [Holidays](holidays.md)
- [Switching teams](switching-teams.md)
- [Impact reviews](../../departments/people-talent/people-ops/process/teammate-sentiment/impact-reviews/index.md)
- [Leaving](../../departments/people-talent/people-ops/process/leaving.md)
- [Teammate development](teammate-development/index.md)
- [Recognition and #thanks Channel best practices](../../benefits-pay-perks/benefits-perks/celebrate.md#regular-thanks-and-recognition-via-our-thanks-channel)
- [Career Ladders](career-frameworks.md)
