export { generateNextJSProject, type ExportedFile } from "./generator";
