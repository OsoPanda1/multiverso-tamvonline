__all__ = ["Setting"]


class Setting:
    pass
