cd Server
python3 Server.py