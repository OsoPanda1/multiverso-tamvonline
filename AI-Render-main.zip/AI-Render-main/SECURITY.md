# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

Report any potential vulnerabilities here: https://github.com/benrugg/AI-Render/issues

Issues on this repo are actively monitored, and you should expect a response within 24-48 hours or sooner.
